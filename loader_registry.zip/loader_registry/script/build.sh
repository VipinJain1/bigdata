#!/usr/bin/env bash

# script/bootstrap: Resolve all dependencies that the application requires to
#                   run.

SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ ${SOURCE} != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done

# This variable contains the directory of the script
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

if [ $? -eq 0 ]; then
  echo "==> Install maven dependencies…"
  #mvn --file $DIR/../../../../pom.xml -pl gas/bp/loader_registry/common,gas/bp/loader_registry/formal_validation,gas/bp/loader_registry/substantial_validation -P Enel.Next.Artefacts, -P Enel.Next.Public, -P Enel.Next.Thirdparty clean install -am -amd
  mvn --file $DIR/../../../../pom.xml -pl gas/bp/loader_registry/common,gas/bp/loader_registry/formal_validation -P Enel.Next.Artefacts, -P Enel.Next.Public, -P Enel.Next.Thirdparty clean install -am -amd
  if [ $? -eq 0 ]; then
    echo "==> build finished"
  else
    echo "==> build finished with error"
    exit -1
  fi
else
  echo "==> build finished with error"
  exit -1
fi
