package it.enel.next.enelenergia.power.bp.loader_registry.fv.application

import java.sql.Timestamp

import com.holdenkarau.spark.testing.DatasetSuiteBase
import it.enel.next.enelenergia.gas.bp.loader_registry.common.enum.{EEGLREventTypeEnum, EEGLRProcessEnum}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.EEGValidMappingObject
import it.enel.next.framework.test.tag.{HBaseTest, SlowTest, SparkTest}
import it.enel.next.platform.framework.common.RandomUtils
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.framework.common.model.event._
import it.enel.next.platform.framework.common.model.utility.UID
import it.enel.next.platform.framework.common.spark.udt.SparkUDT
import it.enel.next.platform.service.datalayer.common.connection.SimpleConnectionManager
import it.enel.next.platform.service.datalayer.common.service.event.EventQueueInfoDataService
import org.apache.spark.sql.Encoders
import org.scalatest.FlatSpec


class EEGLREventRepositorySuite extends FlatSpec  with DatasetSuiteBase {
  override implicit def enableHiveSupport: Boolean = false

  override implicit def reuseContextIfPossible: Boolean = true

  implicit val ctx: NextExecutionContext =
    NextExecutionContext("EventTestApplicationModule", new Timestamp(System.currentTimeMillis()))

  override def beforeAll(): Unit = {
    //super.beforeAll()
    SparkUDT.registerAll()
    val eInfo: EventQueueInfo = EventQueueInfo(
      uid = UID.generate(),
      eventType = EEGLREventTypeEnum.EEG_LOADER_REGISTRY,
      producerGroup = QueueProducerGroup(EEGLRProcessEnum.EEGLoaderRegistryFormalValidationNP),
      consumerGroup = QueueConsumerGroup(EEGLRProcessEnum.EEGLoaderRegistrySubstantialValidationNP),
      path = "hdfs://nameservice1/user/ae101045/immutable_event_queue/gas_data/" + RandomUtils.randomAlphaString(20),
      partitions = Set(0),
      format = JsonImmutableEventQueueFormat,
      lastConsumerOp = None,
      lastTsOp = None,
      schema = Some(Encoders.product[Event[EEGValidMappingObject]].schema.json)
    )
    (new EventQueueInfoDataService with SimpleConnectionManager).insertElement(eInfo)
//        (new EventQueueInfoDataService with SimpleConnectionManager).deleteElement(eInfo)
  }

  "Event Check" should "write events" taggedAs(HBaseTest, SlowTest, SparkTest) in{
    val eegLoaderRegQueue = (new EventQueueInfoDataService with SimpleConnectionManager)
      .findSimple(EEGLREventTypeEnum.EEG_LOADER_REGISTRY.name)
    assert(eegLoaderRegQueue.isDefined)

  }



}
