package it.enel.next.enelenergia.power.bp.loader_registry.fv.application



import java.net.URI

import com.holdenkarau.spark.testing.DatasetSuiteBase
import com.typesafe.config.Config
import it.enel.next.enelenergia.gas.bp.loader_registry.common.enum.EEGLRProcessEnum
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.process.EEGLoaderRegistryFormalValidationNP
import it.enel.next.enelenergia.gas.common.model.discard.EEGFormalValidationDiscard
import it.enel.next.enelenergia.gas.common.model.postasales.EEGPostSales
import it.enel.next.enelenergia.gas.service.dl.common.discard.EEGFormalValidationDiscardDS
import it.enel.next.enelenergia.gas.service.dl.common.postasales.EEGPostSalesDS
import it.enel.next.platform.framework.common.EnvironmentUtils
import it.enel.next.platform.framework.common.configuration.NextConfigurationFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.scalatest.{FlatSpec, Matchers}

class EEGLRFormalValidationNPSuite extends FlatSpec with Matchers with DatasetSuiteBase {

  val CURRENT_USER: String = "next"
  System.setProperty("HADOOP_USER_NAME", CURRENT_USER)

  override implicit def enableHiveSupport: Boolean = false

  override implicit def reuseContextIfPossible: Boolean = true

  implicit lazy val implicitSpark = spark

  //  implicit lazy val fs = FileSystem.getLocal(spark.sparkContext.hadoopConfiguration)
  lazy val fsHost: String = {
    Option((new Configuration).get("dfs.nameservices"))
      .getOrElse(throw new IllegalArgumentException("hadoopConf did not declare nameservices"))
  }

  implicit lazy val fs: FileSystem = FileSystem.newInstance(URI.create("hdfs://" + fsHost), sc.hadoopConfiguration)

  override def beforeAll(): Unit = {
    println(getClass.getClassLoader.getResource("org/apache/hadoop/fs/GlobalStorageStatistics.class"))
    super.beforeAll()
    EnvironmentUtils.reset()
  }

  val PROCESSING: String = "processing"
  val PROCESSED: String = "processed"

  "InputCheckTest" should "run without throwing exceptions" in {
    noException should be thrownBy {
      spark.sparkContext.setLogLevel("INFO")
      System.setProperty(EnvironmentUtils.SPARK_APP_NAME,
        EEGLRProcessEnum.EEGLoaderRegistryFormalValidationNP.name)
      val myConfig: Config = NextConfigurationFactory.load("EEGLoaderRegistryFormalValidationNP.conf")
      EEGLoaderRegistryFormalValidationNP.runJob(myConfig)
    }
  }

  "Check Discarded Table Content" should "find discarded entity in HBase EG:Discard" in {
    println("###### Formal Validation Discarded entity #####")
    val optDiscardedEntity: Option[EEGFormalValidationDiscard] = EEGFormalValidationDiscardDS.findDiscarded("623456")
    assert(optDiscardedEntity.isDefined)
    val entity = optDiscardedEntity.get
    println(s"Entity Found, printing attributes:\n\tId Elaboration: ${entity.idElaborationFile}\n\tStatus Notes:")
    entity.lstStatusNotes.foreach(s => println(s"\t\tCode: ${s.codStatusNotes}" +
      s"\n\t\tReason: ${s.reason.getOrElse("-->NO REASONS<--")}"))
    println(s"\t\tDiscard:${entity.discard.toString}")
  }

  "Check PostSales Table Content" should "find PostSales entity in HBase EG:PostSales" in {
    println("###### Formal Validation PostSales entity #####")
    val postSalesSeq: Seq[EEGPostSales] = EEGPostSalesDS.findPostSales("55881205759499")
    assert(postSalesSeq.size > 0)

    postSalesSeq.map(p => {
      println(s"Entity Found, printing attributes:\n\tPOD: ${p.pod}\n\tStatus Notes:")
      println(s"\t\tProcess Causal:${p.processCausal}")
      println(s"\t\tProcess SubCausal:${p.processSubCausal}")
      p.lstProcessData.foreach(s => println(s"\t\tCode: ${s.codErrTransmission}" +
        s"\n\t\tResult: ${s.trasmissionResult.getOrElse("-->NO RESULT<--")} " +
        s"\n\t\tStatus: ${s.transmissionStatus.getOrElse("-->NO STATUS<--")} " +
        s"\n\t\tIdRequest: ${s.idRequest.getOrElse("-->NO ID REQUEST<--")} " +
        s"\n\t\tCustomer Number: ${s.customerNumber.getOrElse("-->NO CUSTOMER NUMBER<--")} " +
        s"\n\t\tResult: ${s.result}" +
        s"\n\t\tResultDesc: ${s.resultDescription.getOrElse("-->NO REASONS<--")} "))

    })
  }
}
