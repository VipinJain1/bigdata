package it.enel.next.enelenergia.gas.bp.loader_registry.fv.process

import com.typesafe.config.Config
import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGSupplyActivationFVEObject, EEGSupplyActivationFVEntity => FVE}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.EEGSupplyActivationAM
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.EEGSupplyActivationDataContext
import it.enel.next.platform.framework.collection.massive.datastructure.NextRDD
import it.enel.next.platform.framework.collection.massive.datastructure.NextRDD.RddConverter
import it.enel.next.platform.framework.common.metadata.{NextMetadata}
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.framework.process.NextProcess
import it.enel.next.platform.service.bucketing.model.{GenericWorkUnit, NoOpProgressTracker}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import it.enel.next.platform.service.bucketing.model.ProgressTracker
import it.enel.next.platform.framework.collection.common.datastructure.NextCollection
import it.enel.next.platform.framework.common.metadata.NextObjectWrapper

object EEGLoaderRegistryFormalValidationNP extends NextProcess[TLR,FVE,EEGSupplyActivationDataContext]{

  override type AM = EEGSupplyActivationAM.type

  override protected def applicationModule = EEGSupplyActivationAM

  override protected def readInput(implicit fs: FileSystem, sparkSession: SparkSession, conf: Config,
                                   ctx: NextExecutionContext):
  Seq[ProgressTracker[NextCollection[NextObjectWrapper[FVE]]]] = {

    val rdd = sparkSession.sparkContext
      .textFile(conf.getString(Constants.SOURCE_PATH))
      .map(x => (x, x.replace("||",";")))
    val split = rdd.map( x => (x._1, x._2.split(";",Constants.NO_LIMIT) ) )

    split.persist

    val knownRecordsRDD = split.filter(x =>
      x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.ANAG) ||
        x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.CC_PDR) ||
        x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.CC_SITO)
    )

    val unknowRecordsRDD = split.filter(x =>
      !x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.ANAG) &&
        !x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.CC_PDR) &&
        !x._2(Constants.TYPE_RECORD_FIELD).equals(Constants.CC_SITO)
    )

    val typeRec = knownRecordsRDD.map(x=>( x._1,{ x._2(Constants.TYPE_RECORD_FIELD) match {
      case Constants.ANAG => x._2(Constants.ID_CRM_ANAG_FIELD)+:x._2
      case _ => x._2(x._2.size-1)+:x._2 //Last field is the ID_CRM (Request ID)
    }
    }))

    val groupedRDD: RDD[(String, Iterable[(String, Array[String])])] = typeRec.groupBy(x => x._2(0))

    val datasetGroupedByIdCrm: RDD[(String, Seq[(String, Array[String])])] = groupedRDD.map(x => (x._1, x._2.toSeq))

    val formalValidationEntityRDD: RDD[FVE] =
      datasetGroupedByIdCrm.map(elem => EEGSupplyActivationFVEObject.parse(elem))

    val formalValidationUnknownRDD: RDD[FVE] =
      unknowRecordsRDD.map(elem => EEGSupplyActivationFVEObject.parseUnknown(elem))

    val formalValidationFullRDD: RDD[FVE] = formalValidationEntityRDD.union(formalValidationUnknownRDD)

    split.unpersist()

    val wrappedEntities: NextRDD[NextObjectWrapper[FVE]] =
      formalValidationFullRDD.map(elem => NextObjectWrapper(elem, NextMetadata.empty)).wrap
    val workingUnitList = List(GenericWorkUnit(wrappedEntities,Some(conf.getString(Constants.SOURCE_PATH))))

    Seq(new NoOpProgressTracker[NextCollection[NextObjectWrapper[FVE]]](workingUnitList))
  }
}

protected object Constants{
  val TYPE_RECORD_FIELD: Int = 6
  val ID_CRM_ANAG_FIELD: Int = 81
  val ID_CRM_CC_FIELD: Int = 51
  //  val SOURCE_PATH: String = "path"
  //  val DESTINATION_PATH: String = "pathToDestination"
  val NO_LIMIT: Int = -1
  val ANAG: String = "ANAG"
  val CC_PDR: String = "CC_PDR"
  val CC_SITO: String = "CC_SITO"
  val SOURCE_PATH = "read_input_path.input"
  val DESTINATION_PATH = "read_input_path.output"
  val ImmutableQueuePath = "immutable_events_path"
}
