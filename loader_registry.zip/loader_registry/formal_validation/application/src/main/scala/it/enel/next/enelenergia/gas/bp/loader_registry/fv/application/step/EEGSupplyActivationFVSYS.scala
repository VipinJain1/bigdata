package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGSupplyActivationFVEntity => FVE}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.utils.StringOps
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.RecordTypeSegregatorService
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationFVE, EEGSupplyActivationFVEEnum, EEGSupplyActivationPostgresTables => PTBL, EEGSupplyActivationConstants => CONST}
import it.enel.next.platform.cross.coremodule.formalvalidation.application.FormalValidationSyntacticValidation
import it.enel.next.platform.cross.model.ValidationError
import it.enel.next.platform.framework.common.logging.Logging
import it.enel.next.platform.framework.common.metadata.NextObjectWrapper
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.framework.common.typological.TypologicalDataService
import it.enel.next.platform.service.datalayer.common.typological.TypologicalTableRepository

import scala.collection.mutable.ListBuffer

//scalastyle:off
trait EEGSupplyActivationFVSYS extends FormalValidationSyntacticValidation[FVE] with Logging {
  import scala.language.implicitConversions
  private implicit def stringToStringOps(s: String): StringOps = StringOps(s)
  var errorList: ListBuffer[ValidationError] = new ListBuffer[ValidationError]

  def genericChecks(fve: FVE) = {
    // CHECK n. G01
    if (fve.payload.isDefined && fve.payload.get.size != CONST.two) {
      if (fve.payload.get.size == 1 && fve.payload.get(0)(7) == CONST.ANAG && fve.payload.get(0)(CONST.sixteen) == CONST.M ) {
          errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true, 2, fve.payload.get.size)
      }
      (0 to fve.payload.get.size - 1).map(i => {
        if (fve.payload.get(i)(7) == CONST.ANAG && fve.payload.get.apply(i)(CONST.sixteen) == CONST.M) {
          errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true, 2, fve.payload.get.size)
        }
      })
    }
    // CHECK n. G02
    else if (fve.unknownPayload.isDefined && fve.unknownPayload.get.nonEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1009, true, fve.unknownPayload.get.mkString(","))
    }
    //CHECK n. G03
    //TODO
    // CHECK n. G04
    else if ((0 to fve.payload.get.size - 1).map(i => fve.payload.get(i)(7)).distinct.size != fve.payload.get.size) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_20, true, fve.payload.get(1)(CONST.seven))
    }
    // CHECK n. G05
    else if (fve.payload.isDefined && fve.payload.get.size != CONST.three) {
      if (fve.payload.get.size == 1 && fve.payload.get(0)(7) == CONST.ANAG && fve.payload.get(0)(CONST.sixteen) == CONST.B ) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true, 3, fve.payload.get.size)
      }
      (0 to fve.payload.get.size - 1).map(i => {
        if (fve.payload.get(i)(7) == CONST.ANAG && fve.payload.get.apply(i)(CONST.sixteen) == CONST.B) {
          errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true, 3, fve.payload.get.size)
        }
      })
    }
  }

  def genericChecksSpecific(anag: Array[String], pdr: Array[String], sito: Array[String]) = {
    // CHECK n. G06
    if ((anag(CONST.sixteen) == CONST.B && !(anag(CONST.seven) == CONST.ANAG && sito(CONST.seven) == CONST.CC_SITO && pdr(CONST.seven) == CONST.CC_PDR))
      || (anag(CONST.sixteen) == CONST.M && !(anag(CONST.seven) == CONST.ANAG && pdr(CONST.seven) == CONST.CC_PDR))){
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_21, true, anag.mkString(","))
    }
    // CHECK n. G07
    else if ((anag(CONST.sixteen) == CONST.B &&
        !(anag(80) == sito(26) && anag(80) == pdr(50) && sito(26) == pdr(50) && anag(81) == pdr(51) && sito(27) == pdr(51)))
      || (anag(CONST.sixteen) == CONST.M &&
        !(anag(80) == pdr(50) && anag(81) == pdr(51)))){
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_22, true)
    }
  }

  def checkA49Partial(anag: Array[String]): Boolean = {
    if (!anag(CONST.sixtyFour).isEmpty || !anag(CONST.sixtyFive).isEmpty || !anag(CONST.sixtySix).isEmpty
      || !anag(CONST.sixtySeven).isEmpty || !anag(CONST.sixtyEight).isEmpty || !anag(CONST.sixtyNine).isEmpty || !anag(CONST.seventyOne).isEmpty ||
      !anag(CONST.seventyTwo).isEmpty || !anag(CONST.seventyThree).isEmpty || !anag(CONST.seventyFive).isEmpty || !anag(CONST.seventySix).isEmpty ||
      !anag(CONST.seventySeven).isEmpty || !anag(CONST.seventyEight).isEmpty || !anag(CONST.seventyNine).isEmpty) {
      true
    } else {
      false
    }
  }

  def anagBlockingChecks(anag: Array[String]): Unit = {
    // CHECK n. A01
    if (!anag.length.equals(CONST.eightyThree)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, anag.size - CONST.seven)
    }
    // CHECK n. A02
    else if (anag(CONST.eight).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "data inizio relazione")
    }
    else if (anag(CONST.eight).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, anag(8).length, 10)
    }
//    else if (anag(CONST.eight).length > 2) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1, true, "data inizio relazione")
//    }
    else if (anag(CONST.eight).isEmpty && anag(60).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "data inizio relazione")
    }
    // Not checked
    else if (anag(8).isEmpty && anag(60).nonEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true)
    }
    // CHECK n. A06
    else if (anag(12).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "numero utente")
    }
    else if (anag(12).length != 9) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_23, true)
    }
    else if (!(anag(12).isInt)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, "numero utente", anag(12))
    }
    // CHECK n. A07
    else if (anag(13).isEmpty && anag(CONST.sixteen) == CONST.B) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "codice pod sap")
    }
    else if (anag(13).length > 14) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "codice pod sap", anag(13).length, 14)
    }
    else if (anag(13) == anag(17)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1005_0, true)
    }

    //def anagBlockingChecks(anag: Array[String])(implicit ctx: NextExecutionContext): Unit = {
    // STARTING BLOCKING CHECKS FOR RECORD TYPE ANAG
    //if (anag(CONST.seven).equals(CONST.ANAG)) {


    // CHECK n. A11
    else if (anag(CONST.sixteen).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "tipologia cliente")
    }
    else if (anag(CONST.sixteen).length > 1) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "tipologia cliente",
        anag(CONST.sixteen).length, 1)
    }
    else if (anag(CONST.sixteen) != CONST.M && anag(CONST.sixteen) != CONST.B) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "tipologia cliente", anag(CONST.sixteen))
    }
    // CHECK n. A12
    else if (anag(17).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "codice pod")
    }
    else if (anag(17).length != 14) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "codice pod",
        anag(17).length, 14)
    }
    // CHECK n. A15
    else if (anag(CONST.twentyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "toponimo indirizzo fornitura")
    }
    //TODO Below to be moved to Mapping Step
//    else if (anag(CONST.twentyTwo).length > 100) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "toponimo indirizzo fornitura",
//        anag(CONST.twentyTwo).length, 100)
//    }
    // CHECK n. A22
    else if (anag(CONST.thirtyThree).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "flag cliente diretto")
    }
    else if (anag(CONST.thirtyThree).length > 1) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "flag cliente diretto",
        anag(CONST.thirtyThree).length, 1)
    }
    //    else if (anag(CONST.thirtyThree) != CONST.N && anag(CONST.thirtyThree) != CONST.S) {
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "flag cliente diretto", anag(CONST.thirtyThree))
    //    }
    else if (!Seq(CONST.S,CONST.N).contains(anag(CONST.thirtyThree))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "flag cliente diretto", anag(CONST.thirtyThree))
    }
    // Error code EER_1042_42 is not present.... Added the error code in EEGSupplyActivationFVE
    else if (anag(CONST.thirtyThree) == CONST.S && anag(CONST.sixteen) == CONST.M) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_42, true)
    }
    // CHECK n. A24
    else if (anag(CONST.thirtySix).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "societa distributrice")
    }
    else if (anag(CONST.thirtySix).length > 20) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, 20)
    }
    else if (anag(CONST.thirtyEight).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "codice istat comune")
    }
    else if (anag(CONST.thirtyEight).length > 6) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, 6)
    }
    // CHECK n A26
      //TODO move to Mapping Step
//    else if (anag(CONST.thirtyNine).length > 1) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "stato pdr",
//        anag(CONST.thirtyNine).length, 1)
//    }
    // CHECK A.27
    else if (anag(CONST.fourty).isEmpty && anag(CONST.sixteen) == 'B') {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_2, true, "codice remi")
    }
    else if (anag(CONST.fourty).length > 100) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "codice remi", anag(CONST.fourty), 100)
    }
    // CHECK n. 32
    else if (anag(CONST.fourtySix).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "matricola apparecchiatura misuratore")
    }
    else if (anag(CONST.fourtySix).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "matricola apparecchiatura misuratore",
        anag(CONST.fourtySix).length, 30)
    }
    else if (anag(CONST.fourtySeven).equals(anag(CONST.sixtyFour)) && anag(CONST.fourtySix).equals(anag(CONST.sixtyThree))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1, true)
    }
    //error
    //    else if ((anag(CONST.thirtyThree).equals(CONST.S)) && ((anag(CONST.fourtySix).length != 8) || (anag(CONST.fourtySix).length != 30))) {
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1041_1, true)
    //    }
    else if ((anag(CONST.thirtyThree).equals(CONST.S)) && (!Seq(8,30).contains(anag(CONST.fourtySix).length))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1041_1, true)
    }
    // CHECK n. 33
    else if (anag(CONST.fourtySeven).length > CONST.two) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true,
        "codice marca apparecchiatura misuratore", anag(CONST.fourtySeven).length, 2)
    }

    //    else if(arrElem(CONST.fourtySeven).equals(arrElem(CONST.sixtyFour)) && arrElem(CONST.fourtyNine).equals(arrElem(CONST.sixtyThree))){
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true)
    //    }
    //    else if(arrElem(CONST.thirtyThree).equals(CONST.S) && arrElem(CONST.fourtySix).length != CONST.eight){
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1041_1, true)
    //    }
    //    else if(arrElem(CONST.fourtySeven).length > CONST.two){
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true)
    //    }
    //    else if(arrElem(CONST.fourtySeven).isEmpty){
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Measuring equipment maker code", arrElem(CONST.fourtySeven).length, CONST.two)
    //    }

    // CHECK 34
    else if (anag(CONST.fourtyEight).length > CONST.hundred) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "tipo apparecchiatura misuratore", anag(CONST.fourtyEight).length, 100)
    }
    else if (anag(CONST.fourtyEight).equals(CONST.C)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_24, true)
    }
    else if ((anag(CONST.fourtyEight).equals(CONST.R)) && (!anag(CONST.sixtyThree).isEmpty && !anag(CONST.sixtyFour).isEmpty &&
      !anag(CONST.sixtyFive).isEmpty && !anag(CONST.seventyFive).isEmpty && !anag(CONST.seventySix).isEmpty)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_1, true)
    }
    else if (anag(CONST.fourtyEight).equals(CONST.R) && anag(CONST.thirtyThree).equals(CONST.N)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_0, true)
    }
    else if (anag(CONST.fourtyEight).equals(CONST.M) && anag(CONST.thirtyThree).equals(CONST.S)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_2, true)
    }
    else if (anag(CONST.fourtyEight).equals(CONST.R) && !anag(CONST.sixty).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_0, true)
    }
    else if (anag(CONST.fourtyEight) != CONST.C && anag(CONST.fourtyEight) != CONST.M && anag(CONST.fourtyEight) != CONST.R) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "tipo apparecchiatura misuratore", anag(CONST.fourtyEight))
    }
    // CHECK n. 35
    else if (anag(CONST.fourtyNine).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "data installazione misuratore", anag(CONST.fourtyNine).length, 10)
    }
    else if (!anag(CONST.fourtyNine).validateDateFormat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1, true, "data installazione misuratore")
    }
    else if (anag(CONST.fourtyNine) != anag(CONST.eight)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7, true, "data installazione misuratore",
        anag(CONST.fourtyNine), anag(CONST.eight))
    }
    //CHECK n.37
    //TODO check 3rd and 4th condition with dino
//    else if (anag(CONST.fiftyOne).length > CONST.two) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "cifre misuratore", anag(CONST.fiftyOne).length, CONST.two)
//    }
    else if (!(anag(CONST.fiftyOne).isInt)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, "cifre misuratore", anag(CONST.fiftyOne))
    }
    else if (anag(CONST.fiftyOne).length < CONST.four && anag(CONST.fourtyEight).equals(CONST.M)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23, true, anag(CONST.fiftyOne).length, CONST.four)
    }
    else if (anag(CONST.fiftyOne).length > CONST.ten && anag(CONST.fourtyEight).equals(CONST.M)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23_1, true, anag(CONST.fiftyOne).length, CONST.ten)
    }
    // CHECK n. 38
    else if (anag(CONST.fiftyTwo).length > CONST.eight) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "calibro misuratore", anag(CONST.fiftyTwo).length, CONST.eight)
    }
    // CHECK n. 44
    else if (anag(CONST.fiftyEight).length > 1) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "stato apparecchiatura misuratore",
        anag(CONST.fiftyEight).length, 1)
    }

    // CHECK n. 46
    else if (anag(CONST.sixty).isEmpty && !anag(CONST.sixtyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "data lettura misuratore")
    }
    else if (anag(CONST.sixty).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "data lettura misuratore", anag(CONST.sixty).length, 10)
    }
    else if (!anag(CONST.sixty).validateDateFormat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1, true, "data lettura misuratore")
    }
    else if (anag(CONST.sixty) != anag(CONST.seventySeven)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_25, true)
    }
    else if (anag(CONST.sixty) != anag(CONST.eight)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_43, true)
    }
    // CHECK n.47
    // TODO A47-4 mapping check remaining
    else if (anag(CONST.sixtyOne).isEmpty && !anag(CONST.sixty).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "tipo lettura misuratore")
    }
    else if (anag(CONST.sixtyOne).length > 2) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "tipo lettura misuratore",
        anag(CONST.sixtyOne).length, 2)
    }
    else if (anag(CONST.sixtyOne) != anag(CONST.seventyEight)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_25, true)
    }
    // CHECK 48
    else if (anag(CONST.sixtyTwo).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "segnante misuratore", anag(CONST.sixtyTwo).length, CONST.ten)
    }
    else if (!(anag(CONST.sixtyTwo)).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "segnante misuratore")
    }
    else if (anag(CONST.sixtyTwo).length > anag(CONST.fiftyOne).getIntValue) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001_1, true)
    }
    else if (!anag(CONST.sixtyTwo).isEmpty && anag(CONST.thirtyThree).equals(CONST.S)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_26, true)
    }
    // CHECK n. 49
    else if ((anag(CONST.sixtyThree).isEmpty) && checkA49Partial(anag)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "matricola apparecchiatura correttore")
    }
    /*else if(arrElem(CONST.sixtyThree).isEmpty && checkAbc(arrElem)){
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "Freshman corrector")
    }*/
    else if (anag(CONST.sixtyThree).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "matricola apparecchiatura correttore")
    }

    //Added ERR_GASERRREMI_3 in EEGSupplyActivationFVE and changed ERR_GASERRREMI_4 to _3
    else if (!anag(CONST.sixtyThree).isEmpty && anag(CONST.fourtySix).equals(CONST.R)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_3, true, "matricola apparecchiatura correttore")
    }
    else if (!anag(CONST.sixtyThree).isEmpty && anag(CONST.thirtyThree).equals(CONST.S)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASERRREMI_3, true, "matricola apparecchiatura correttore")
    }
    // CHECK n. 50
    else if (anag(CONST.sixtyFour).length > CONST.two) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true,
        "codice marca apparecchiatura correttore", anag(CONST.sixtyFour).length, CONST.two)
    }
    // CHECK n. 51
    else if (anag(CONST.sixtyFive).length > CONST.hundred) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "tipo apparecchiatura correttore",
        anag(CONST.sixtyFive).length, CONST.two)
    }
    else if (!anag(CONST.sixtyFive).equals(CONST.C)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_27, true)
    }
    //     else if (!anag(CONST.sixtyFive).contains(Seq(CONST.C, CONST.M, CONST.R))) {
    //       errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true,
    //         "tipo apparecchiatura correttore", anag(CONST.sixtyFive))
    //     }
    //TODO to be verified
    else if (!(Seq(CONST.C, CONST.M, CONST.R).contains(anag(CONST.sixtyFive)))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true,
        "tipo apparecchiatura correttore", anag(CONST.sixtyFive))
    }

    //CHECK 54
    else if (anag(CONST.sixtyEight).length > CONST.two) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "cifre correttore",
        anag(CONST.sixtyEight).length, CONST.two)
    }
    else if (anag(CONST.sixtyEight).getIntValue < CONST.four) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23_2, true, anag(CONST.sixtyEight), CONST.four)
    }
    else if (anag(CONST.sixtyEight).getIntValue > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23_3, true, anag(CONST.sixtyEight), CONST.ten)
    }
    // CHECK A55
    else if (anag(CONST.sixtyNine).length > CONST.eight) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "calibro correttore",
        anag(CONST.sixtyNine).length, CONST.eight)
    }
    //CHECK A59
    else if (!anag(CONST.seventyThree).equals(anag(CONST.fiftySix))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001_2, true)
    }
    //TODO confirm whether it is value or size
    else if (anag(CONST.seventyThree).length > CONST.hundred) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "accessibilita fisica correttore",
        anag(CONST.seventyThree).length, CONST.thirteen)
    }
    // CHECK n. 61
    else if (anag(CONST.seventyFive).length > 1) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "stato apparecchiatura correttore",
        anag(CONST.seventyFive).length, 1)
    }
    // CHECK n. A63
    else if (anag(CONST.seventySeven).isEmpty && !anag(CONST.sixty).isEmpty && !anag(CONST.sixtyThree).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_28, true)
    }
    else if (!anag(CONST.seventySeven).isEmpty && anag(CONST.sixtyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_29, true)
    }
    //ToDo verify with Sushil
    else if (!anag(CONST.seventySeven).validateDateFormat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, true, "data lettura correttore")
    }
    else if (anag(CONST.seventySeven).length > 10) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true,
        "data lettura correttore", anag(CONST.seventySeven).length, 10)
    }
    //CHECK A64
    else if (anag(CONST.seventyEight).length > CONST.two) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "tipo lettura correttore",
        anag(CONST.seventyEight).length, 2)
    }
    //CHECK A65
    else if (anag(CONST.seventyNine).isEmpty && !anag(CONST.sixtyThree).isEmpty && !anag(CONST.sixtyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_30, true)
    }
    else if (!anag(CONST.seventyNine).isEmpty && anag(CONST.thirtyThree).equals(CONST.S)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_26, true)
    }
    else if (!anag(CONST.seventyNine).isEmpty && anag(CONST.sixtyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1043_0, true)
    }
    //TODO check whether it is 5 or 9
    else if (!anag(CONST.seventyNine).isEmpty && anag(CONST.sixtyEight).isEmpty && anag(CONST.seventyNine).length > CONST.nine) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001_3, true, anag(CONST.fiftyOne), CONST.five)
    }
    else if (anag(CONST.seventyNine).length > anag(CONST.sixtyEight).getIntValue) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001_4, true)
    }
    else if (!(anag(CONST.seventyNine).isFloat)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "segnante correttore")
    }
    else if (anag(CONST.seventyNine).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, CONST.ten)
    }
    //CHECK n.A66
    else if (anag(CONST.eighty).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "causale processo crm")
    }
    else if (anag(CONST.eighty).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "causale processo crm",
        anag(CONST.eighty).length, CONST.thirty)
    }
    //removed string
    else if (!anag(CONST.eighty).equals(CONST.ATTIVAZIONE)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_31, true, anag(CONST.eighty))
    }
    //CHECK A67
    else if (anag(CONST.eightyOne).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true,
        "sottocausale processo crm")
    }
    else if (anag(CONST.eightyOne).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "sottocausale processo crm",
        anag(CONST.eightyOne).length, CONST.thirty)
    }
    //     else if (anag(CONST.eightyOne).contains(Seq(CONST.VARIAZIONEUSO, CONST.RENEGOTIATION, CONST.MIGRATION, CONST.FREQUENZALETTURA, CONST.MOGE))) {
    //       errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_32, true)
    //      }
    //TODO to be verified
    else if (Seq(CONST.VARIAZIONEUSO, CONST.RICONTRATTUALIZZAZIONE, CONST.MIGRAZIONE, CONST.FREQUENZALETTURA, CONST.MOGE).contains(anag(CONST.eightyOne))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_32, true)
    }
    //CHECK A68
    else if (anag(CONST.eightyTwo).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "ANAG")
    }
    else if (anag(CONST.eightyTwo).length > CONST.twenty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "id richiesta",
        anag(CONST.eightyTwo).length, CONST.twenty)
    }
    //CHECK A69
//    else if (anag(CONST.eightyThree).length > CONST.fifteen) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "comunicazione",
//        anag(CONST.eightyThree).length, CONST.fifteen)
//    }
    //     else if (!anag(CONST.eightyThree).contains(Seq("NORMALE", CONST.FORCED, CONST.FORCED_TEMP))) {
    //       errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_33, true, anag(CONST.eightyThree))
    //     }
    //TODO to be verified
//    else if (!(Seq("NORMALE", CONST.FORCED, CONST.FORCED_TEMP).contains(anag(CONST.eightyThree)))) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_33, true, anag(CONST.eightyThree))
//    }
  }

  def anagNonBlockingChecks(anag: Array[String])(implicit ctx: NextExecutionContext) :Unit = {
    // CHECK n. A03
    if (anag(9).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1003_1, false, anag(9).size)
    }
    //TODO move to mapping step
//    else if (anag(9).length != 11 && anag(9).length != CONST.sixteen ) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, anag(CONST.nine))
//    }
//    else if (anag(9).length == 11 && !(anag(9).isInt)) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, false, anag(CONST.nine))
//    }
    // CHECK n. A04
    if (anag(10).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_f, false, "descrizione cliente")
    }
    //TODO move to mapping step
//    else if (anag(10).length > 100 ) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, 100)
//    }
//    // CHECK n. A05
//    if (anag(11).length > 20) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, 20)
//    }
    // CHECK A07
    //    if (!anag(CONST.thirteen).isEmpty && anag(CONST.sixteen).equals(CONST.M)) {
    //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1003_1, false)
    //    }
    //CHECK A08
    if (anag(CONST.fourteen).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, false, "descrizione contratto sito")
    }
    //TODO move to mapping step
//    else if (anag(CONST.fourteen).length > CONST.twenty) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "descrizione contratto sito",
//        anag(CONST.fourteen).length, 14)
//    }
    //CHECK A09
//    if (!anag(CONST.fifteen).length.equals(CONST.eleven)) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "partita iva contratto sito", anag(CONST.fifteen).length, 20)
//    }
//    else if (!(anag(CONST.fifteen).isInt)) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, "partita iva contratto sito",anag(CONST.fifteen))
//    }

    //CHECK A16
    //TODO move to mapping step
//    if (!(anag(CONST.twentyThree).isEmpty) && anag(CONST.twentyThree).length > 4000) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "note indirizzo fornitura")
//    }
    //CHECK A17
//    if (anag(CONST.twentyFour).length > 100) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "comune indirizzo fornitura", anag(CONST.twentyFour).length, 100)
//    }

    //CHECK A18
    //TODO move to mapping step
//    if (anag(CONST.twentyFive).length > CONST.five) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "cap indirizzo fornitura", anag(CONST.twentyFive).length, CONST.five)
//    }
//    else if (!(anag(CONST.twentyFive).isInt)) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, anag(CONST.twentyFive))
//    }
//    else if (anag(CONST.twentySeven).length > CONST.three){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "appartamento indirizzo fornitura", anag(CONST.twentySeven).length, CONST.three)
//    }
//    CHECK A19
//    if (anag(CONST.twentySix).length > CONST.two){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "provincia indirizzo fornitura", anag(CONST.twentySix).length, CONST.two)
//    }
//    else if (anag(CONST.twentyEight).length > CONST.six){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "numero civico indirizzo fornitura", anag(CONST.twentyEight).length, CONST.six)
//    }
//    //CHECK A20
//    if (anag(CONST.twentyNine).length > CONST.two){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "scala indirizzo fornitura", anag(CONST.twentyNine).length, CONST.two)
//    }
//    //CHECK A21
//    if (anag(CONST.thirty).length > CONST.two){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "piano indirizzo fornitura", anag(CONST.thirty).length, CONST.two)
//    }
//    else if (anag(CONST.thirtyOne).length > CONST.hundred){
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "referente email", anag(CONST.thirtyOne).length, CONST.hundred)
//    }
    //CHECK A23
//    if (anag(CONST.thirtyFour).length > CONST.four) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "dug", anag(CONST.thirtyFour).length, 4)
//    }
//    //CHECK A28
//    if (anag(CONST.fourtyOne).length > 4000) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "note gas pdr anag")
//    }
//    // CHECK A29
//    if (!(anag(CONST.fourtyThree).isEmpty) && (anag(CONST.sixteen) == 'M')) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_37, false)
//    }
//    else if (anag(CONST.fourtyThree).length > 20) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "impianto", anag(CONST.fourtyThree).length, 20)
//    }
//    // CHECK A30
//    if (!anag(CONST.fourtyFour).isEmpty && anag(CONST.sixteen) == 'M') {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_38, false)
//    }
//    else if (anag(CONST.fourtyFour).length > 50) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "località aeeg", anag(CONST.fourtyFour).length, 50)
//    }
//    // CHECK 31
//    if (anag(CONST.fourtyFive).length > 50) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "tipologia gas", anag(CONST.fourtyFive).length, 50)
//    }
//     CHECK 36
//    if (anag(CONST.fifty).length > CONST.four) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "anno costruzione misuratore", anag(CONST.fifty).length, 4)
//    }
//    else if (!anag(CONST.fifty).isInt) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, "anno costruzione misuratore", anag(CONST.fifty))
//    }
    // CHECK A39
//    if (anag(CONST.fiftyThree).length > 1) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "posizione misuratore", anag(CONST.fiftyThree).length, 1)
//    }
//    // CHECK A40
//    if (anag(CONST.fiftyFour).length > 8) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "potenzialità misuratore", anag(CONST.fiftyFour).length, 8)
//    }
//    else if (!anag(CONST.fiftyFour).isInt) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, "potenzialita misuratore", anag(CONST.fiftyFour))
//    }
//    // CHECK A41
//    if (anag(CONST.fiftyfive).length > 13) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "pressione misuratore", anag(CONST.fiftyfive).length, 13)
//    }
//    else if (!anag(CONST.fiftyfive).isFloat) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, false, "pressione misuratore")
//    }
//    // CHECK A42
//    if (anag(CONST.fiftySix).length > 100) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "accessibilità fisica", anag(CONST.fiftySix).length, 100)
//    }
    //    else if (anag(CONST.fiftySix).isEmpty && !anag(CONST.seventyThree).isEmpty) {
    //
    //    }
    //    else if (anag(CONST.fiftySix).isEmpty && anag(CONST.seventyThree).isEmpty) {
    //
    //    }
    // CHECK A43
//    if (anag(CONST.fiftySeven).length > 8) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "max prelievo orario contrattuale misu.", anag(57).length, 8)
//    }
    if (!anag(CONST.fiftySeven).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, false, "max prelievo orario contrattuale misu.")
    }
    // CHECK A45
    if (anag(CONST.fiftyNine).length > 4000) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "note apparecchiatura misuratore",
        anag(CONST.fiftyNine).length, 4000)
    }
    // CHECK A52
    //    else if (anag(66).isEmpty && !anag(63).isEmpty) {
    //
    //    }
    if (anag(CONST.sixtySix).length > 10) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "data installazione correttore", anag(CONST.sixtySix).length, 10)
    }
    else if (!anag(CONST.sixtySix).validateDateFormat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, false, "data installazione correttore")
    }
    else if (anag(CONST.sixtySix) != anag(49)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7_2, false, "data installazione correttore",
        anag(CONST.sixtySix), anag(49))
    }
    else if (anag(CONST.sixtySix) != anag(8)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7, false, "data installazione correttore", anag(CONST.sixtySix), anag(8))
    }
    //TODO move to mapping step
    // CHECK A53
//    if (!anag(CONST.sixtySeven).isInt) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, "anno costruzione correttore", anag(CONST.sixtySeven))
//    }
//    else if (anag(CONST.sixtySeven).length > 4) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "anno costruzione correttore", anag(CONST.sixtySeven).length, 4)
//    }
//    // CHECK A56
//    if (anag(CONST.seventy).length > 1) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "posizione correttore", anag(CONST.seventy).length, 1)
//    }
//    // CHECK A57
//    if (!anag(CONST.seventyOne).isInt) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false, "potenzialita correttore", anag(CONST.seventyOne))
//    }
//    else if (anag(CONST.seventyOne).length > 8) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "potenzialità correttore", anag(CONST.seventyOne).length, 8)
//    }
//    // CHECK A58
//    if (!anag(CONST.seventyTwo).isFloat) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, false, "pressione correttore")
//    }
//    else if (anag(CONST.seventyTwo).length > 13) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "pressione correttore", anag(CONST.seventyTwo).length, 13)
//    }
//    // CHECK A60
//    if (!anag(CONST.seventyFour).isFloat) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, false, "MAX PRELIEVO ORARIO CONTRATTUALE CORR.")
//    }
//    else if (anag(CONST.seventyFour).length > 8) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, "MAX PRELIEVO ORARIO CONTRATTUALE CORR.", anag(CONST.seventyFour).length, 8)
//    }
    // CHECK A61
    //    else if (anag(75).isEmpty && anag(63) != null) {
    //
    //    }
    // CHECK A62
//    if (anag(CONST.seventySix).length > 4000) {
//      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false,	"note apparecchiatura correttore", anag(CONST.seventySix).length, 4000)
//    }

  }

  def ccpdrBlockingChecks(anag: Array[String], pdr: Array[String]) = {
    if (pdr(CONST.seven) == CONST.CC_PDR) {
      // CHECK n. R01
      if (anag(CONST.sixteen) == CONST.B && pdr.length != 53) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, anag.size - CONST.seven)
      }
      // CHECK n. R02
      else if (anag(CONST.sixteen) == CONST.M && pdr.length != 53) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, anag.size - CONST.seven)
      }
      // CHECK n. R03
      else if (pdr(CONST.seven).isEmpty) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Record type")
      }
      // CHECK R04
      else if (pdr(CONST.eight).isEmpty) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Pod Code")
      }
      else if (!pdr(CONST.eight).equals(anag(CONST.seventeen))) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_40, true)
      }
      else if (pdr(CONST.eight).length < CONST.fourteen) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1040_0, true, "Pod Code", pdr(CONST.eight).length, CONST.fourteen)
      }
      else if (pdr(CONST.eight).length > CONST.fourteen) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Pod Code", pdr(CONST.eight).length, CONST.fourteen)
      }
      // CHECK R05
      else if (pdr(CONST.ten).isEmpty && (anag(CONST.sixteen) ==CONST.B) && !(pdr(CONST.fiftyOne) == CONST.VAC)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_3, true)
      }
      else if (pdr(CONST.ten).isEmpty && pdr(CONST.eleven).isEmpty && (anag(CONST.sixteen) == CONST.M)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_4, true)
      }
      else if (!(pdr(CONST.ten).isInt)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, pdr(CONST.ten))
      }
      else if (pdr(CONST.ten).length > CONST.eight) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Annual contract volume pdr", pdr(CONST.ten).length, CONST.fourteen)
      }
      // CHECK R06
      else if (!(pdr(CONST.eleven).isInt)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, pdr(CONST.ten))
      }
      else if (pdr(CONST.eleven).length > CONST.eight) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Distributor annual consumption", pdr(CONST.eleven).length, CONST.eight)
      }
      // CHECK R07
      else if (!(pdr(CONST.twelve).isFloat)  ) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "ktvo")
      }
      else if (pdr(CONST.twelve).length > CONST.ten) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "ktvo", pdr(CONST.twelve).length, CONST.ten)
      }
      // CHECK R08
      else if (pdr(CONST.thirteen).isEmpty) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "cc early date")
      }
      else if(!pdr(CONST.thirteen).validateDateFormat) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, true, "cc early date")
      }
      else if (pdr(CONST.thirteen).length > CONST.ten) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Start date cc", pdr(CONST.thirteen).length, CONST.ten)
      }
      else if (!pdr(CONST.thirteen).equals(anag(CONST.eight))) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7_3, true, "Start date cc", anag(CONST.eight), pdr(CONST.thirteen))
      }
      //CHECK R09
      // TODO R09 remaining(need to check R09 with sushil)
      else if (pdr(CONST.fifteen).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "use type", pdr(CONST.fifteen), CONST.one)
      }
      // CHECK R10
      else if (pdr(CONST.sixteen).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Industrial uses", pdr(CONST.sixteen), CONST.one)
      }
      // CHECK R11
      else if (!(pdr(CONST.seventeen).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.seventeen))
      }
      else if (pdr(CONST.seventeen).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage industrial uses", pdr(CONST.seventeen).length, CONST.six)
      }
      // CHECK R12
      else if (pdr(CONST.eighteen).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Chemical process", pdr(CONST.eighteen).length, CONST.one)
      }
      // CHECK R13
      else if (!(pdr(CONST.nineteen).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.nineteen))
      }
      else if (pdr(CONST.nineteen).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage industrial uses", pdr(CONST.nineteen), CONST.six)
      }
      // CHECK R14
      else if (pdr(CONST.twenty).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "automotive", pdr(CONST.twenty), CONST.one)
      }
      // CHECK R15
      else if (!(pdr(CONST.twentyOne).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.twentyOne))
      }
      else if (pdr(CONST.twentyOne).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage automotive", pdr(CONST.twentyOne).length, CONST.six)
      }
      // CHECK R16
      else if (pdr(CONST.twentyTwo).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Armed Forces", pdr(CONST.twentyTwo).length, CONST.one)
      }
      // CHECK R17
      else if (!(pdr(CONST.twentyThree).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.twentyThree))
      }
      else if (pdr(CONST.twentyThree).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage Armed Forces", pdr(CONST.twentyThree).length, CONST.six)
      }
      // CHECK R18
      else if (pdr(CONST.twentyFour).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Energy production", pdr(CONST.twentyFour), CONST.one)
      }
      // CHECK R19
      else if (!(pdr(CONST.twentyFive).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.twentyFive))
      }
      else if (pdr(CONST.twentyFive).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage automotive", pdr(CONST.twentyFive).length, CONST.six)
      }
      // CHECK R20
      else if (pdr(CONST.twentySix).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Sale of energy", pdr(CONST.twentySix).length, CONST.one)
      }
      // CHECK R21
      else if (!(pdr(CONST.twentySeven).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.twentySeven))
      }
      else if (pdr(CONST.twentySeven).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage Assignment energy", pdr(CONST.twentySeven).length, CONST.six)
      }
      // CHECK R22
      else if (pdr(CONST.twentyEight).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Civil cooking foods", pdr(CONST.twentyEight), CONST.one)
      }
      // CHECK R23
      else if (!(pdr(CONST.twentyNine).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.twentyNine))
      }
      else if (pdr(CONST.twentyNine).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage Civil cooking foods", pdr(CONST.twentyNine).length, CONST.six)
      }
      // CHECK R24
      else if (pdr(CONST.thirty).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Civil promiscuous", pdr(CONST.thirty).length, CONST.one)
      }
      // CHECK R25
      else if (!(pdr(CONST.thirtyOne).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.thirtyOne))
      }
      else if (pdr(CONST.thirtyOne).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage Civil promiscuous", pdr(CONST.twentySeven).length, CONST.six)
      }
      // CHECK R26
      else if (pdr(CONST.thirtyTwo).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Civilians other uses", pdr(CONST.thirtyTwo), CONST.one)
      }
      // CHECK R27
      else if (!(pdr(CONST.thirtyThree).isFloat)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, pdr(CONST.thirtyThree))
      }
      else if (pdr(CONST.thirtyThree).length > CONST.six) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage Civilian other uses", pdr(CONST.thirtyThree).length, CONST.six)
      }
      // CHECK R29
      else if (pdr(CONST.fourtyTwo).length > CONST.three){
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Category duso", pdr(CONST.fourtyTwo).length, CONST.three)
      }
      // CHECK R30
      else if (pdr(CONST.fourtyThree).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "Drawing boxes", pdr(CONST.fourtyThree).length, CONST.one)
      }
      //CHECK R31
      else if (pdr(CONST.fourtyFour).length > CONST.five) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Withdrawal of Standard Profile", pdr(CONST.fourtyFour), CONST.one)
      }
      //CHECK R32
      else if (pdr(CONST.fourtyFive).isEmpty && anag(CONST.sixteen).equals(CONST.M)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_34, true)
      }
      else if (pdr(CONST.fourtyFive).length > CONST.eleven) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Progressive Consumption", pdr(CONST.fourtyFive), CONST.eleven)
      }
      //CHECK R33
      else if (pdr(CONST.fourtySix).isEmpty && !anag(CONST.fiftyOne).equals(CONST.VCA)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_3, true)
      }
      else if (!pdr(CONST.fourtySix).equals(CONST.G) && anag(CONST.thirtyThree).equals(CONST.S)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_41, true, pdr(CONST.fourtySix) )
      }
      //TODO make it > CONST.one
      else if (pdr(CONST.fourtySix).length > CONST.one) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Frequency Reading" ,pdr(CONST.fourtySix).length,CONST.one )
      }
      // CHECK 34
      //    else if (pdr(CONST.fifty).isEmpty) {
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "causal process")
      //    }
      //    else if (!pdr(CONST.fifty).equals(CONST.ACTIVATION)){
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_31, true, pdr(CONST.fifty))
      //    }
      //    else if (pdr(CONST.fifty).length > CONST.thirty){
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Causal Process",pdr(CONST.fifty), CONST.thirty)
      //    }
      //    // CHECK 35
      //    else if (pdr(CONST.fiftyOne)isEmpty){
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "sottocausale process crm")
      //    }
      //    else if (pdr(CONST.fiftyOne).contains(Seq(CONST.VARIAZIONEUSO,CONST.RENEGOTIATION,CONST.FREQUENZALETTURA, CONST.MIGRATION
      //    , CONST.MOGE))){
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_35, true)
      //    }
      //    else if (pdr(CONST.fiftyOne).length > CONST.thirty ){
      //      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Sottocausale Process", pdr(CONST.fiftyOne).length, CONST.thirty)
      //    }
    }
  }

  def ccpdrNonBlockingChecks(anag: Array[String],pdr: Array[String]): Unit = {
    if (pdr(CONST.seven) == CONST.CC_PDR) {
      // CHECK n. R09
      if (pdr(15).isEmpty) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false)
      }
      // CHECK n. R28
      if (pdr(34).length > 2) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, false, CONST.potenzaFranchigia
          ,pdr(34).size, 2)
      } else if (!(pdr(34).isInt)) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, false)
      }else if (!pdr(34).isEmpty && anag(CONST.sixteen) == CONST.B ) {
         errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_1, false)
      }
    }
  }

  def ccsitoBlockingChecks(anag: Array[String], sito: Array[String]): Unit = {
    // CHECK n. M01
    if (anag(CONST.sixteen) == CONST.B && sito.length != CONST.twentyNine) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, sito.size - CONST.seven)
    } // CHECK n. M02
    else if (sito(CONST.seven).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "tipo record")
    }
    else if (sito(CONST.seven) == CONST.CC_SITO && anag(CONST.sixteen) == CONST.M) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_36, true)
    }
    // CHECK n. M03
    else if (sito(CONST.eight).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "numero utente")
    }
    else if (!sito(CONST.eight).isInt) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, "numero utente",
        sito(CONST.eight))
    }
    else if (sito(CONST.eight) != anag(CONST.twelve)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_40, true)
    }
    else if (sito(CONST.eight).length > CONST.twenty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "numero utente",
        sito(CONST.eight).length, CONST.twenty)
    }
    // CHECK M04
    else if (sito(CONST.nine).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "data inizio cc")
    }
    else if (!sito(CONST.nine).validateDateFormat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, true, "data inizio cc")
    }
    else if (sito(CONST.nine).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "data inizio cc"
        , sito(CONST.nine).length, CONST.twenty)
    }
    else if (LocalDate.parse(sito(9), DateTimeFormatter.ofPattern(CONST.dtPattern)).isAfter(
      LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7_3, true, anag(CONST.eight), sito(CONST.nine))
    }
    //CHECK M05
    else if (!sito(CONST.twelve).replace(",", ".").isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "coefficiente profilatura")
    }
    else if (sito(CONST.twelve).length > CONST.thirteen) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "coefficient profiling", sito(CONST.twelve).length, CONST.thirteen)
    }
    //CHECK M06
    else if (!sito(CONST.thirteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 01")
    }
    else if (sito(CONST.thirteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 01"
        , sito(CONST.thirteen).length, CONST.ten)
    }
    //CHECK M07
    else if (!sito(CONST.fourteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 02")
    }
    else if (sito(CONST.fourteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 02"
        , sito(CONST.fourteen).length, CONST.ten)
    }
    //CHECK M08
    else if (!sito(CONST.fifteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 03")
    }
    else if (sito(CONST.fifteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 03"
        , sito(CONST.fifteen).length, CONST.ten)
    }
    //CHECK M09
    else if (!sito(CONST.sixteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 04")
    }
    else if (sito(CONST.sixteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 04"
        , sito(CONST.sixteen).length, CONST.ten)
    }
    //CHECK M10
    else if (!sito(CONST.seventeen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 05")
    }
    else if (sito(CONST.seventeen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 05"
        , sito(CONST.seventeen).length, CONST.ten)
    }
    //CHECK M11
    else if (!sito(CONST.eighteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 06")
    }
    else if (sito(CONST.eighteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 06"
        , sito(CONST.eighteen).length, CONST.ten)
    }
    //CHECK M12
    else if (!sito(CONST.nineteen).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 07")
    }
    else if (sito(CONST.nineteen).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 07"
        , sito(CONST.nineteen).length, CONST.ten)
    }
    //CHECK M13
    else if (!sito(CONST.twenty).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 08")
    }
    else if (sito(CONST.twenty).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 08"
        , sito(CONST.twenty).length, CONST.ten)
    }
    //CHECK M14
    else if (!sito(CONST.twentyOne).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 09")
    }
    else if (sito(CONST.twentyOne).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 09"
        , sito(CONST.twentyOne).length, CONST.ten)
    }
    //CHECK M15
    else if (!sito(CONST.twentyTwo).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 10")
    }
    else if (sito(CONST.twentyTwo).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 10"
        , sito(CONST.twentyTwo).length, CONST.ten)
    }
    //CHECK M16
    else if (!sito(CONST.twentyThree).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 11"
      )
    }
    else if (sito(CONST.twentyThree).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 11"
        , sito(CONST.twentyThree).length, CONST.ten)
    }
    //CHECK M17
    else if (!sito(CONST.twentyFour).isFloat) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 12")
    }
    else if (sito(CONST.twentyFour).length > CONST.ten) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 12"
        , sito(CONST.twentyFour).length, CONST.ten)
    }
    // CHECK 18
    else if (sito(CONST.twentySix).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "causale processo")
    } else if (!sito(CONST.twentySix).equals(CONST.ATTIVAZIONE)) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_31, true, sito(CONST.twentySix))
    } else if (sito(CONST.twentySix).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "causale processo", sito(CONST.twentySix).length, CONST.thirty)

    //CHECK 19
    } else if (sito(CONST.twentySeven).isEmpty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true,"sottocausale process")
    } else if (Seq(CONST.VARIAZIONEUSO,CONST.RICONTRATTUALIZZAZIONE, CONST.MIGRAZIONE,CONST.FREQUENZALETTURA, CONST.MOGE).contains(sito(CONST.twentySeven))) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_35, true)
    } else if (sito(CONST.twentySeven).length > CONST.thirty) {
      errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "sottocausale process ", sito(CONST.twentySeven).length, CONST.thirty)
    }
  }

  override def validateSyntactically(item: NextObjectWrapper[FVE])(implicit ctx: NextExecutionContext):
  (Boolean, Seq[ValidationError]) = {
    genericChecks(item.optEntity.get)
    if (errorList.isEmpty) {
      val (anag, pdr, sito) = RecordTypeSegregatorService.getRecordTypeArrays(item.optEntity.get)
      genericChecksSpecific(anag, pdr, sito)
      if (errorList.isEmpty) anagBlockingChecks(anag)
      if (errorList.isEmpty) ccpdrBlockingChecks(anag, pdr)
      if (errorList.isEmpty && !sito.isEmpty) ccsitoBlockingChecks(anag, sito)

      if (errorList.isEmpty) {
        ccpdrNonBlockingChecks(anag, pdr) +: anagNonBlockingChecks(anag) +: errorList
          (false, errorList.toSeq)
      } else {
        (true, errorList.toSeq)
      }
    } else{
      ( true, errorList.toSeq)
    }
  }

  /**
    * Get the typologicalDataService object from TypologicalTableRepository
    * @param ctx
    * @return
    */
  private def typologicalDataService()(implicit ctx: NextExecutionContext): Option[TypologicalDataService] = {
    ctx.typologicalInfo match {
      case Some(ti) => Option(TypologicalTableRepository.get)
      case None => None
    }
  }

  def anagBlockingChecksAT1(anag: Array[String])(implicit ctx: NextExecutionContext): Unit = {
      val tds = typologicalDataService()
      if(tds.isDefined)
      {
        if (anag(CONST.thirtySix).nonEmpty && !tds.get.hasRecord(PTBL.T_SD, anag(CONST.thirtySix), LocalDate.now())) {
          errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Sales company", anag(CONST.thirtySix))
        }
        else{

        }

      }
  }

  def anagBlockingChecksAT2A11(anag: Array[String])(implicit ctx: NextExecutionContext): Unit = {

    val tds = typologicalDataService()
    if (tds.isDefined) {
      val distType = tds.get.getValue(PTBL.T_SD, anag(CONST.thirtySix), "COD_DISTRIBUTOR_TYPE")

      if (anag(CONST.thirtySix).nonEmpty && !tds.get.hasRecord(PTBL.T_SD, anag(CONST.thirtySix), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Sales company", anag(CONST.thirtySix))
      } else if ((anag(CONST.thirtyThree).toString == "S" && distType.getOrElse("").toString != "DR") || (anag(CONST.thirtyThree) == "N" && distType.getOrElse("").toString != "DR")) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Sales company", anag(CONST.thirtySix))
      } else if (anag(CONST.thirtyEight).nonEmpty && !tds.get.hasRecord(PTBL.T_CI, anag(CONST.thirtyEight), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Common istat code", anag(CONST.thirtyEight))
      } else if (anag(CONST.thirtyNine).nonEmpty && !tds.get.hasRecord(PTBL.T_PDR, anag(CONST.thirtyNine), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Pdr was", anag(CONST.thirtyNine))
      } else if (anag(CONST.fourtySeven).nonEmpty && !tds.get.hasRecord(PTBL.T_MB, anag(CONST.fourtySeven), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Code brand meter equipment", anag(CONST.fourtySeven))
      } else if (anag(CONST.sixtyFour).nonEmpty && !tds.get.hasRecord(PTBL.T_MB, anag(CONST.sixtyFour), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Code checker branded equipment", anag(CONST.sixtyFour))
      } else if (anag(CONST.fiftyTwo).nonEmpty && !tds.get.hasRecord(PTBL.T_CAL, anag(CONST.fiftyTwo), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Meter gauge", anag(CONST.fiftyTwo))
      } else if (anag(CONST.sixtyNine).nonEmpty && !tds.get.hasRecord(PTBL.T_CAL, anag(CONST.sixtyNine), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Corrector caliber", anag(CONST.sixtyNine))
      } else if (anag(CONST.fiftySix).nonEmpty && !tds.get.hasRecord(PTBL.T_AF, anag(CONST.fiftySix), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Measuring physical accessibility", anag(CONST.fiftySix))
      } else if (anag(CONST.seventyThree).nonEmpty && !tds.get.hasRecord(PTBL.T_AF, anag(CONST.seventyThree), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Corrector physical accessibility", anag(CONST.seventyThree))
      } else if (anag(CONST.seventyOne).nonEmpty && !tds.get.hasRecord(PTBL.T_MT, anag(CONST.seventyOne), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Meter reading type", anag(CONST.seventyOne))
      } else if (anag(CONST.seventyEight).nonEmpty && !tds.get.hasRecord(PTBL.T_MT, anag(CONST.seventyEight), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Read type checker", anag(CONST.seventyEight))
      }
    }
  }

  def anagNonBlockingChecksAT4(anag: Array[String])(implicit ctx: NextExecutionContext): Unit = {
    val tds = typologicalDataService()
    //
    if(tds.isDefined) {
       if(anag(CONST.fourty).nonEmpty && !tds.get.hasRecord(PTBL.T_CR, anag(CONST.fourty), LocalDate.now())){
           errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_39, true, "Pdr was", anag(CONST.fourty))
         }
    }
  }

  def ccpdrBlockingChecksRT1RT5(anag: Array[String], pdr: Array[String])(implicit ctx: NextExecutionContext): Unit = {
    val tds = typologicalDataService()
   //
    if(tds.isDefined) {
      val isCodeProfile = ccpdrBlockingChecksRT3(anag, pdr)

      if (pdr(CONST.fourtyTwo).nonEmpty && !tds.get.hasRecord(PTBL.T_UC, anag(CONST.fourtyTwo), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Duso category", pdr(CONST.fourtyTwo))
      } else if (pdr(CONST.fourtyThree).nonEmpty && !tds.get.hasRecord(PTBL.T_CP, anag(CONST.fourtyThree), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Pickup", pdr(CONST.fourtyThree))
      } else if(pdr(CONST.fourtyFour).nonEmpty && !isCodeProfile){
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Standard withdrawal profile", pdr(CONST.fourtyFour))
      } else if(pdr(CONST.fourtySix).nonEmpty && !tds.get.hasRecord(PTBL.T_RF, anag(CONST.fourtySix), LocalDate.now())) {
        errorList += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_0, true, "Read frequency", pdr(CONST.fourtySix))
      }
    }
  }

  def ccpdrBlockingChecksRT3(anag: Array[String], pdr: Array[String])(implicit ctx: NextExecutionContext): Boolean = {
    val tds = typologicalDataService()
    var resultTpp:Iterable[Map[String,Any]] = Seq.empty
    if (tds.isDefined) {
      val recordsTpp = tds.get.getAllRecords(PTBL.T_PP, LocalDate.now())
         resultTpp = recordsTpp.values.filter(rec =>
        rec.get(CONST.codeProfile).getOrElse("") == anag(CONST.fourtyFour))
    }
    if(resultTpp.size > 0)
      true
    else
      false
  }
}
//scalastyle:on
