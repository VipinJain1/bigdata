package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.dl

import it.enel.next.enelenergia.gas.bp.loader_registry.common.enum.EEGLRRoutingOutputEnum
import it.enel.next.enelenergia.gas.common.model.discard.EEGFormalValidationDiscard
import it.enel.next.enelenergia.gas.service.dl.common.discard.EEGFormalValidationDiscardDS
import it.enel.next.enelenergia.gas.service.dl.common.postasales.EEGPostSalesDS
import it.enel.next.platform.framework.common.model.application.RoutingOutputEnumBase
import it.enel.next.platform.framework.common.model.{NextObject, Tailor}
import it.enel.next.platform.service.datalayer.common.service.{Catalog, DataService}

object EEGLoadRegistryFormalValidationDiscardedItemCatalog extends Catalog{

  private val _dataServices: Map[String, Map[RoutingOutputEnumBase.RoutingOutputEnumValue,
    DataService[Tailor, NextObject with Tailor]]] = Map (
    EEGFormalValidationDiscard.identifierName -> Map(
      EEGLRRoutingOutputEnum.DISCARDED_ITEM ->
        EEGFormalValidationDiscardDS.asInstanceOf[DataService[Tailor, NextObject with Tailor]]
    ),
    "EEGPostSales" -> Map(
      EEGLRRoutingOutputEnum.POST_SALES ->
        EEGPostSalesDS.asInstanceOf[DataService[Tailor, NextObject with Tailor]]
    )

  )

  override def getDataService(identifierName: String, destination: RoutingOutputEnumBase.RoutingOutputEnumValue):
  Option[DataService[Tailor, NextObject with Tailor]] = {
    _dataServices.get(identifierName).flatMap(m => m.get(destination))
  }

}
