package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.dl

import com.typesafe.config.Config
import it.enel.next.enelenergia.common.model.EnelEnergiaTailor
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.Outcome
import it.enel.next.platform.framework.common.metadata.NextObjectWrapper
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.service.write.massive.files.transformer.TransformerToString

class EEGLRTextTransformer extends TransformerToString[EnelEnergiaTailor, Outcome]{

  override def transform(obj: NextObjectWrapper[Outcome], config: Config)(implicit nec: NextExecutionContext):
  Seq[String] = {
    Seq(obj.optEntity.get.outcome)
  }
}
