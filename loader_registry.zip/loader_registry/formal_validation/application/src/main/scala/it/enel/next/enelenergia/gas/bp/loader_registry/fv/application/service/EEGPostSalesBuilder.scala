
package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service

import java.time.{ZoneId, ZonedDateTime}

import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.EEGSupplyActivationFVEntity
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationPostgresTables, EEGSupplyActivationConstants => CONST}
import it.enel.next.enelenergia.gas.common.model.postasales.EEGPostSales
import it.enel.next.platform.cross.model.ValidationError
import it.enel.next.platform.cross.model.postsales.PostSalesResultEnum.KO
import it.enel.next.platform.framework.common.logging.Logging
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.framework.common.typological.TypologicalDataService
import it.enel.next.platform.gas.common.model.postsales.{DatiMat, GasProcessData}
import it.enel.next.platform.service.datalayer.common.typological.TypologicalTableRepository

object EEGPostSalesBuilder extends Logging {

  def create(fve: EEGSupplyActivationFVEntity, errors: Seq[ValidationError])(implicit ctx: NextExecutionContext):
    Option[EEGPostSales] = {
    val payload = fve.payload.get
    val (anag, pdr, sito) = RecordTypeSegregatorService.getRecordTypeArrays(fve)

    val isPdr = sito.isEmpty

    val (processCausal, processSubcausal, requestId): (String, String, String) = if (sito.isEmpty) {
      (pdr(CONST.fifty), pdr(CONST.fiftyOne), pdr(CONST.fiftyTwo))
    }else {
      (sito(CONST.twentySix), sito(CONST.twentySeven), sito(CONST.twentyEight))
    }
    val causalSubCausal = getCausalValues(processCausal, processSubcausal)

    if (isPdr) {
      //TO DO  need check this 2 and 4 chars
      if (causalSubCausal._1.isDefined && causalSubCausal._2.isDefined) {
        Some(EEGPostSales(anag(CONST.seventeen), fve.timeZone, fve.uid, Option(CONST.EMPTY),
          ZonedDateTime.now(ZoneId.of("UTC")), None, fve.source, ZonedDateTime.now(ZoneId.systemDefault()),
          causalSubCausal._1.get.toString, causalSubCausal._2.get.toString, KO,
          List(GasProcessData(ZonedDateTime.now(ZoneId.systemDefault()), KO, None,
            Option(requestId), None, None, None, Option(anag(CONST.eighteen)), None, None, None, None,
            DatiMat(None, None, None, None, None, None, None, None, None, None, None, None, None, None,
              None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)))))
      } else {
        log.info(s"process Causal subcausal not found for pod ${anag(CONST.seventeen)}")
        None
      }
    } else {

      if (causalSubCausal._1.isDefined && causalSubCausal._2.isDefined) {
        Some(EEGPostSales(anag(CONST.seventeen),fve.timeZone, fve.uid, Option(CONST.EMPTY),
          ZonedDateTime.now(ZoneId.of("UTC")), None, fve.source,ZonedDateTime.now(ZoneId.systemDefault()),
          causalSubCausal._1.get.toString, causalSubCausal._2.get.toString,KO,
          List(GasProcessData(ZonedDateTime.now(ZoneId.systemDefault()),KO, None,
            Option(sito(CONST.twentyEight)),None, None, None,Option(anag(CONST.eighteen)), None, None, None, None,
            DatiMat(None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,
              None,None,None,None,None,None,None,None,None)))))
      } else{
        log.info(s"process Causal subcausal not found for pod ${anag(CONST.seventeen)}")
        None
      }
    }
  }

  def getCausalValues(causal: String, subcausal: String)(implicit ctx: NextExecutionContext): (Option[Any], Option[Any])
  = {
    val causalSubCausalMap = getCausalSubCausalMap()
    if (causalSubCausalMap.isDefined) {
      causalSubCausalMap.get.values.
        map(m => (m.get("DES_CASUAL"), m.get("DES_SUBCAUSAL"), m.get("COD_CAUSAL"), m.get("COD_SUBCAUSAL"))).
        filter(e => (e._1 == Some(causal) && e._2 == Some(subcausal))).
        map(e => (e._3, e._4)).head
    } else {
      (None, None)
    }
  }

  def getCausalSubCausalMap()(implicit ctx: NextExecutionContext): Option[Map[String, Map[String, Any]]] = {
    val tds: Option[TypologicalDataService] = ctx.typologicalInfo match {
      case Some(t) => Option(TypologicalTableRepository.get)
      case None => None
    }
    if (tds.isDefined) {
      Some(tds.get.getAllRecords(EEGSupplyActivationPostgresTables.T_SD))
    } else {
      None
    }
  }
}
