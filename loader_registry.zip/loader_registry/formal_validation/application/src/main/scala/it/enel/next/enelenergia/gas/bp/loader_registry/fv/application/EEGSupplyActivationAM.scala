package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application

import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGValidMappingObject, EEGSupplyActivationFVEntity => FVE}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step.{EEGSupplyActivationFVMS, EEGSupplyActivationFVRS, EEGSupplyActivationFVSS, EEGSupplyActivationFVSYS}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.EEGSupplyActivationDataContext
import it.enel.next.enelenergia.gas.common.model.registry.{EEGRegistry => REG}
import it.enel.next.platform.cross.coremodule.formalvalidation.application.FormalValidationApplicationModule
import it.enel.next.platform.cross.coremodule.formalvalidation.application.custom.FormalValidationApplicationCustom
import it.enel.next.platform.framework.application.CustomModule
import it.enel.next.platform.framework.application.model.CustomOutput
import it.enel.next.platform.framework.application.step._

object EEGSupplyActivationAM
  extends FormalValidationApplicationModule[TLR,FVE,REG,EEGSupplyActivationDataContext] with Serializable
    with FlyByMainSubmoduleStep[TLR, FVE, EEGSupplyActivationDataContext]
    with DefaultPreFetchFilterStep[TLR, FVE]
    with DefaultCustomStep[TLR, FVE, EEGSupplyActivationDataContext]
    with DefaultWriteStep[TLR]
    with DefaultEventStep[TLR]
{
  protected override def customModule: CustomModule[TLR, FVE, EEGSupplyActivationDataContext] =
    new FormalValidationApplicationCustom[TLR, FVE, EEGValidMappingObject, EEGSupplyActivationDataContext]
      with EEGSupplyActivationFVSYS
      with EEGSupplyActivationFVMS
      with EEGSupplyActivationFVSS
      with EEGSupplyActivationFVRS


  override def moduleName: String = "EEGLoaderRegistryFormalValidationAM"

  override protected def postWrite(subMOutput: CustomOutput[TLR]): Boolean = true
}

