package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalTime, ZoneId, ZonedDateTime}

import it.enel.next.enelenergia.common.model.EnelEnergiaTailor
import it.enel.next.enelenergia.gas.bp.loader_registry.common.metadata.EEGLoaderRegistryMetadataKeys
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGValidMappingObject, EEGSupplyActivationFVEntity => FVE}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.utils.StringOps
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.{EEGPostSalesBuilder, RecordTypeSegregatorService}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationConstants => CONST}
import it.enel.next.enelenergia.gas.common.model.contract_site.EEGContractSite
import it.enel.next.enelenergia.gas.common.model.measure.EEGCommercialMeasure
import it.enel.next.enelenergia.gas.common.model.registry._
import it.enel.next.enelenergia.gas.common.model.typological_percentages.EEGTypologicalPercentages
import it.enel.next.platform.cross.coremodule.formalvalidation.application.FormalValidationMapping
import it.enel.next.platform.cross.model.{Percentage, ValidationError}
import it.enel.next.platform.framework.common.logging.Logging
import it.enel.next.platform.framework.common.metadata.{NextMetadata, NextObjectWrapper}
import it.enel.next.platform.framework.common.model.application.NextExecutionContext
import it.enel.next.platform.framework.common.model.discard.StatusNote
import it.enel.next.platform.framework.common.model.measure.{MapSign, RcdBillingStatus}
import it.enel.next.platform.framework.common.model.registry._

import scala.language.implicitConversions
import scala.collection.mutable.ListBuffer
// scalastyle:off
trait EEGSupplyActivationFVMS extends FormalValidationMapping[EnelEnergiaTailor, FVE, EEGValidMappingObject] with Logging{
  private implicit def stringToStringOps(s: String): StringOps = StringOps(s)
    override def createNextEntity(syntacticValidItem: NextObjectWrapper[FVE])(implicit ctx: NextExecutionContext):
    Either[NextObjectWrapper[EEGValidMappingObject], Seq[ValidationError]] = {

    val anagWarnErrorList: ListBuffer[ValidationError] = ListBuffer()
    val fve = syntacticValidItem.optEntity.get
    val (anag, pdr, sito) = RecordTypeSegregatorService.getRecordTypeArrays(fve)

    val isPdr = sito.isEmpty
    val pdrOrSito = if (isPdr) pdr else sito
    val extraMappingValues = metaDataExtraMapping(fve, pdr, sito)

    // TODO [MAPPING] checks

    specialChecksAndMapping(anag)

    val uuid = fve.uid
    val processing_Note = fve.processingNote
    val dt_Acquisition = fve.dtAcquisition
    val dt_processingNote = fve.dtProcessing
    val source = fve.source
    val custNum = anag(CONST.twelve)
    val end_val = LocalDate.parse("31/12/2099", DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    val cod_distribtor = anag(CONST.thirtySix)
    val pod = anag(CONST.seventeen)
    val flgClienteDiretto = anag(CONST.thirtyThree) match {
      case "N" => true
      case "S" => false
    }
    val codice_remi = anag(CONST.fourty)
    val tipologia_uso = pdr(CONST.fifteen)
    val tipologia_gas = anag(CONST.fourtyFive)
    val custName = anag(CONST.ten)
    val fiscalCode = anag(CONST.nine)
    val crmCode = anag(CONST.zero)
    val volumeContrattualeAnnuo = pdr(CONST.ten)
    val flgClienteTutelato = pdr(CONST.thirtyEight) match {
      case "N" => true
      case "S" => false
    }
    val metodoStima = anag(CONST.fourtyTwo)
    val progressivoConsumo = pdr(CONST.fourtyFive)
    val frequenzaFatturazione = pdr(CONST.thirtyFour)
    val consumoConcordatoAnnuo = pdr(CONST.fourty)
    val flgBudgetBilling = pdr(CONST.thirtyNine)
    val tipoFatturazione = pdr(CONST.fourtyOne)
    val respLetturaPeriodica = anag(CONST.twentyOne)
    val codIstat = anag(CONST.thirtyEight)
    val referenteMail = anag(CONST.thirtyOne)
    val impianto = anag(CONST.fourtyThree)
    val localitaAeeg = anag(CONST.fourtyFour)

    //FIXME correct below variables
    val codClassPrelievo = "codClassPrelievo"
    val ContractType = "ContractType"
    val statusNote = "statusNote"
    val statusMessage = "M"
    val cifre = "cifre"
    val measureType = "measureType"
    val gasContractSite = if (!sito.isEmpty) {
      //TODO special rul 6
      Some(EEGContractSite(sito(8), uuid, ZoneId.of("UTC"),
        None, fve.dtAcquisition, fve.dtProcessing, fve.source, sito(9).getDateOfFormat.get,  sito(10).getDateOfFormat.get, Option(pod), Option(custName), Option(fiscalCode), sito(12).getOptionalDouble,
        List("testPod", "testPod2"), Map(("01" -> sito(13).getDoubleValue), ("02" -> sito(14).getDoubleValue) ), Option(codice_remi)))
    } else {
       None
     }

    val typologicalPercentages = Option(EEGTypologicalPercentages( pod, uuid, ZoneId.of("UTC"), fve.processingNote,
      fve.dtAcquisition, fve.dtProcessing, fve.source, LocalDate.now(), List(
    Percentage(pdr(16), pdr(17).getDoubleValue), Percentage(pdr(18), pdr(19).getDoubleValue), Percentage(pdr(20), pdr(21).getDoubleValue),
    Percentage(pdr(22), pdr(23).getDoubleValue), Percentage(pdr(24), pdr(25).getDoubleValue), Percentage(pdr(26), pdr(27).getDoubleValue),
    Percentage(pdr(28), pdr(29).getDoubleValue), Percentage(pdr(30), pdr(31).getDoubleValue), Percentage(pdr(32), pdr(33).getDoubleValue)
    )))

    val eegHotContract = EnelEnergiaGasHotContract(Option(anag(41)), fve.dtAcquisition ,
                          fve.dtProcessing, fve.source, anag(16), None, anag(12), None, Option(anag(39)), Option(pdr(44)),
            List(HistDistributor(LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val, anag(36))),
            uuid, LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val, anag(17),
                          ZoneId.of("UTC"), Option(pdr(46)), None, None,None,
                          Seq.empty[StatusNote], pdr(15), Some(flgClienteTutelato), pdr(43),
                          pdr(45).getDoubleValue, flgClienteDiretto, false, Some(metodoStima), pdr(34).getOptionalDouble,
                          List(CodiceRemiStor(LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val, anag(40))))

    val eegColdContract = EnelEnergiaGasColdContract(List(CustomerName(anag(14))), List(FiscalCode(anag(15))),
      Option(ProvisionData(anag(22),anag(24),anag(26),Option(anag(23)))), None, uuid,
      LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), Some(anag(45)),
      List(StoricoVoltura(LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), List(CustomerName(anag(14))),
        Some(anag(11)), List(FiscalCode(anag(15))), anag(12))),
      None,None,None,None, 123456.toLong, pdr(10).toLong,
      Some(pdr(11).getIntValue), anag(38), anag(21), Some(anag(31)), Some(anag(43)),
      Some(anag(44)))

    val eegHotMeasure = EnelEnergiaGasHotMisuratoreMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val, pod,
      ZoneId.of("UTC"),
      //Not memtioned for EEGmeasure in mapping rules hence used from metadata
      processing_Note,
      //Not memtioned for EEGmeasure in mapping rules hence used from metadata
      dt_Acquisition,
      //Not memtioned for EEGmeasure in mapping rules hence used from metadata
      dt_processingNote,
      //Not memtioned for EEGmeasure in mapping rules hence used from metadata
      source,
      Map("Key" -> DatiMisuratoreHotGas(None, None, None, None, None, None, false,
        List(CifreStor(LocalDate.parse(anag(8), DateTimeFormatter.ofPattern(CONST.dtPattern)), None, cifre)),
        None, false, false, false, false)),
      Seq(StatusNote(statusNote,statusMessage,None)))

    val eegColdMeasure = EnelEnergiaGasColdMisuratoreMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)),
      Map("Key" -> DatiMisuratoreColdGas(None,None,None,None,None,None,None)))

    val eegHotCorrectoreMeter = EnelEnergiaGasHotCorrettoreMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val,
      anag(CONST.seventeen),
      ZoneId.of("UTC"),  processing_Note, dt_Acquisition, dt_processingNote, source,
      Map("Key" -> DatiMisuratoreHotGas(None,None,
        None,None,None,None,false,List(CifreStor(LocalDate.parse(anag(8),
          DateTimeFormatter.ofPattern(CONST.dtPattern)),None,cifre)),None,false,false,false,false)),
      Seq(StatusNote(statusNote,statusMessage,None)))

    val eegColdCorrectoreMeter = EnelEnergiaGasColdCorrettoreMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)),
      Map("Key" -> DatiMisuratoreColdGas(None,None,None,None,None,None,None)))

    val eegHotRemiMeter = EnelEnergiaGasHotRemiMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)), end_val, anag(CONST.seventeen),
      ZoneId.of("UTC"),  processing_Note, dt_Acquisition, dt_processingNote, source,
      Map("Key" -> DatiMisuratoreHotGas(None,None,
        None,None,None,None,false,List(CifreStor(LocalDate.parse(anag(8),
          DateTimeFormatter.ofPattern(CONST.dtPattern)),None,cifre)),None,false,false,false,false)),
      Seq(StatusNote(statusNote,statusMessage,None)))

    val eegColdRemiMeter = EnelEnergiaGasColdRemiMeter(uuid,LocalDate.parse(anag(8),
      DateTimeFormatter.ofPattern(CONST.dtPattern)),
      Map("Key" -> DatiMisuratoreColdGas(None,None,None,None,None,None,None)))

    val eegRegistry =  Some(EEGRegistry(Some(Contract(Some(eegHotContract), Some(eegColdContract))),
      Some(Meter(Some(eegHotMeasure),Some(eegColdMeasure))),
      Some(Meter(Some(eegHotCorrectoreMeter),Some(eegColdCorrectoreMeter))),
      Some(Meter(Some(eegHotRemiMeter),Some(eegColdRemiMeter)))))


    val eegMeasure = Some(EEGCommercialMeasure(anag(CONST.seventeen), uuid, ZoneId.of("UTC"),
      ZonedDateTime.of(LocalDate.parse(anag(60), DateTimeFormatter.ofPattern(CONST.dtPattern)),LocalTime.MIDNIGHT, ZoneId.of("UTC")),
      "D", processing_Note, dt_Acquisition, dt_processingNote, source, 1,
      RcdBillingStatus(None, None, None, None, "", 23.122,12.12122, None, None), None, None,
      None, None, None,
      //mapsign is anag(62) according to maaping rules but doesnot match the case class
      MapSign(Map(), None, None),
      List(uuid), None, None,
      None, None, None, None, None, anag(61), None, None, None, None, None, None, None, None, None,
      None, None, None, None, None, 12, Seq(StatusNote(statusNote, statusMessage, None)), None))

    val mappingOutPut = EEGValidMappingObject(gasContractSite, typologicalPercentages, eegRegistry, eegMeasure)

    if (anagWarnErrorList.size > 0) {
      Right(anagWarnErrorList)
    } else {
      Left(NextObjectWrapper(mappingOutPut, NextMetadata.newInstance(extraMappingValues)))
    }
  }

  def metaDataExtraMapping(syntacticValidItem: FVE, pdr: Array[String], sito: Array[String])
                          (implicit ctx: NextExecutionContext): Map[String,Any] = {
    val (processCausal, processSubcausal, requestId) = if (sito.isEmpty) {
      (pdr(CONST.fifty), pdr(CONST.fiftyOne), pdr(CONST.fiftyTwo))
    }else {
      (sito(CONST.twentySix), sito(CONST.twentySeven), sito(CONST.twentyEight))
    }
    val discardedInpuString = syntacticValidItem.payload match {
      case Some(payload) => payload.map(_.mkString(",")).mkString("\n")
      case None if syntacticValidItem.unknownPayload.isDefined => syntacticValidItem.unknownPayload.get.mkString(",")
      case _ => "INPUT STRING EMPTY"
    }

    val (processCausalCodeOption, processSubcausalCodeOption) = EEGPostSalesBuilder.getCausalValues(processCausal, processSubcausal)
    val processCausalCode = processCausalCodeOption match {
      case Some(c) => c
      case None => CONST.EMPTY
    }
    val processSubcausalCode = processSubcausalCodeOption match {
      case Some(c) => c
      case None => CONST.EMPTY
    }

    Map(EEGLoaderRegistryMetadataKeys.DestinationExtraProcessCausal -> processCausal,
    EEGLoaderRegistryMetadataKeys.DestinationExtraProcessSubcausal -> processSubcausal,
    EEGLoaderRegistryMetadataKeys.DestinationExtraProcessCausalCode -> processCausalCode,
    EEGLoaderRegistryMetadataKeys.DestinationExtraProcessSubcausalCode -> processSubcausalCode,
    EEGLoaderRegistryMetadataKeys.DestinationExtraRequestID -> requestId,
    EEGLoaderRegistryMetadataKeys.DestinationExtraInputString -> discardedInpuString,
    EEGLoaderRegistryMetadataKeys.DestinationExtraElaborationID -> syntacticValidItem.meta.elaborationId)
  }


  def specialChecksAndMapping(anag:Array[String]):Unit = {

    anagMappingChecksA01A13(anag)
    anagMappingChecksA14A18(anag)
    anagMappingChecksA19A21(anag)
    anagMappingChecksA23A30(anag)
    anagMappingCheckA31A36(anag)
    anagMappingCheckA39A43(anag)
    anagMappingCheckA39A51(anag)
    anagMappingCheckA53A62(anag)
}

  def anagMappingChecksA01A13(anag:Array[String]) = {
    if(anag(CONST.eight).isEmpty && anag(CONST.sixty).nonEmpty){
      anag(CONST.eight) = anag(CONST.sixty)
    } else if(anag(CONST.nine).toString.equals(CONST.eleven.toString) && anag(CONST.nine).isInt){
      anag(CONST.nine) = null
    } else if(anag(CONST.thirteen).isEmpty && anag(CONST.sixteen).equals((CONST.M))){
      anag(CONST.thirteen) = null
    } else if(!anag(CONST.fifteen).length.equals(CONST.eleven)){
      anag(CONST.fifteen) = null
    } else if(anag(CONST.twentyOne).isEmpty){
      anag(CONST.twentyOne) = null
    } else if(anag(CONST.twentyOne).length > CONST.one){
      anag(CONST.twentyOne) = null
    }
  }

  def anagMappingChecksA14A18(anag:Array[String]) = {
    if(anag(CONST.twentyTwo).length > CONST.hundred){
      anag(CONST.twentyTwo).substring(CONST.zero,CONST.ninetyNine)
    } else if(anag(CONST.twentyThree).length > CONST.fourThousand){
      anag(CONST.twentyTwo).substring(CONST.zero,3999)
    } else if(anag(CONST.twentyFour).length > CONST.hundred){
      anag(CONST.twentyTwo).substring(CONST.zero,CONST.ninetyNine)
    } else if(anag(CONST.twentyFive).length > CONST.five){
      anag(CONST.twentyFive) = null
    }
  }

  def anagMappingChecksA19A21(anag:Array[String]) = {
    if (anag(CONST.twentySix).length > CONST.two) {
      anag(CONST.twentySix).substring(0, 2)
    } else if (anag(CONST.twentySeven).length > CONST.three) {
      anag(CONST.twentySeven).substring(0, 3)
    } else if (anag(CONST.twentyEight).length > CONST.six) {
      anag(CONST.twentyEight).substring(0, 5)
    } else if (anag(CONST.twentyNine).length > CONST.two) {
      anag(CONST.twentyNine).substring(0, 1)
    } else if (anag(CONST.thirty).length > CONST.two) {
      anag(CONST.thirty).substring(0, 1)
    } else if (anag(CONST.thirtyOne).length > CONST.hundred) {
      anag(CONST.thirtyOne).substring(0,99)
    }
  }

  def anagMappingChecksA23A30(anag:Array[String]) = {
    if (anag(CONST.thirtyFour).length > CONST.one){
      anag(CONST.thirtyFour).substring(0,3)
    } else if (anag(CONST.thirtySix).isEmpty && anag(CONST.thirtyThree).equals(CONST.S)){
      anag(CONST.thirtyFour).substring(0,3)
    } else if (anag(CONST.thirtySix).length > CONST.twenty){
      anag(CONST.thirtyFour) = "999999"
    } else if (anag(CONST.fourtyOne).length > CONST.fourThousand){
      anag(CONST.thirtyFour).substring(0,3999)
    } else if (anag(CONST.fourtyOne).length > CONST.fourThousand){
      anag(CONST.thirtyFour).substring(0,3999)
    } else if (anag(CONST.fourtyThree).length > CONST.twenty){
      anag(CONST.fourtyThree).substring(0,19)
    } else if (anag(CONST.fourtyFour).nonEmpty && anag(CONST.sixteen).equals(CONST.M)){
      anag(CONST.fourtyFour) = null
    } else if (anag(CONST.fourtyFour).length > CONST.fifty){
      anag(CONST.fourtyFour).substring(0,49)
    }
  }

  def anagMappingCheckA31A36(anag:Array[String]) = {
    if (anag(CONST.fourtyFive).length > CONST.fifty){
      anag(CONST.fourtyFive).substring(0,49)
    } else if(anag(CONST.fourtySeven).isEmpty){
      anag(CONST.fourtySeven) = "NC"
    } else if(anag(CONST.fourtyNine).isEmpty && anag(CONST.sixteen).equals(CONST.M)){
      anag(CONST.fourtyNine) = anag(CONST.eight)
    } else if(anag(CONST.fourtyNine).isEmpty && anag(CONST.sixteen).equals(CONST.M)){
      anag(CONST.fourtyNine) = anag(CONST.eight)
    } else if (anag(CONST.fifty).length > CONST.four){
      anag(CONST.fifty) = null
    } else if (!anag(CONST.fifty).isInt){
      anag(CONST.fifty) = null
    }
  }

  def anagMappingCheckA39A43(anag:Array[String]) = {
    if (anag(CONST.fiftyThree).length > CONST.one){
      anag(CONST.fiftyThree) = null
    } else if (anag(CONST.fiftyFour).length > CONST.eight){
      anag(CONST.fiftyFour) = null
    } else if (!anag(CONST.fiftyFour).isInt){
      anag(CONST.fiftyFour) = null
    } else if (anag(CONST.fiftyfive).length > CONST.thirteen){
      anag(CONST.fiftyfive) = null
    } else if (!anag(CONST.fiftyfive).isFloat){
      anag(CONST.fiftyfive) = null
    } else if(anag(CONST.fiftySix).isEmpty && anag(CONST.seventyThree).nonEmpty){
      anag(CONST.fiftySix) = anag(CONST.seventyThree)
    } else if(anag(CONST.fiftySix).isEmpty && anag(CONST.seventyThree).isEmpty){
      anag(CONST.fiftySix) = "NOT DEFINED"
    } else if (anag(CONST.fiftySeven).length > CONST.eight){
      anag(CONST.fiftySeven) = null
    }
  }

  def anagMappingCheckA39A51(anag:Array[String]) = {
    if(anag(CONST.fiftyEight).isEmpty && anag(CONST.fourtySix).nonEmpty){
      anag(CONST.fiftyEight) = "A"
    } else if(anag(CONST.fiftyNine).length > CONST.fourThousand){
      anag(CONST.fiftyNine).substring(0,3999)
    } else if(anag(CONST.sixtyTwo).equals(null) && anag(CONST.sixteen).equals(CONST.M)){
      anag(CONST.sixtyTwo) = "PP"
    } else if(anag(CONST.sixtyFour).isEmpty){
      anag(CONST.sixtyFour) = "NC"
    } else if(anag(CONST.sixtyFive).isEmpty && anag(CONST.sixtyThree).nonEmpty){
      anag(CONST.sixtyFive) = "C"
    } else if(anag(CONST.sixtySix).isEmpty && anag(CONST.sixtyThree).nonEmpty){
      anag(CONST.sixtySix) = anag(CONST.eight)
    }
  }

  def anagMappingCheckA53A62(anag:Array[String]) = {
    if (anag(CONST.sixtyEight).isEmpty && anag(CONST.sixtyThree).nonEmpty) {
      anag(CONST.sixtyEight) = "9"
    }

    if (anag(CONST.seventyThree).isEmpty && !anag(CONST.sixtyThree).equals(null)) {
      anag(CONST.seventyThree) = "NON DEFINITVA"
    }

    if (anag(CONST.seventyThree).isEmpty && !anag(CONST.fiftySix).equals(null) && !anag(CONST.fourtySix).equals(null)
      && !anag(CONST.sixtyThree).equals(null)) {
      anag(CONST.seventyThree) = "Accessibilità fisica misuratore"
    }

    if (anag(CONST.seventyThree).isEmpty && !anag(CONST.sixtyThree).equals(null)) {
      anag(CONST.seventyThree) = "NON DEFINITVA"
    }

    if (anag(CONST.seventyFive).isEmpty && !anag(CONST.sixtyThree).equals(null)) {
      anag(CONST.seventyFive) = "2"
    }

    if (anag(CONST.seventySix).length > CONST.fourThousand) {
      anag(CONST.seventyFive).substring(0,3999)
    }
  }
}
//scalastyle:on
