package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service

import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationConstants => CONST}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGSupplyActivationFVEntity => FVE}

object RecordTypeSegregatorService {

  private def getAnagPdr(payload: Seq[Array[String]] ): (Array[String], Array[String], Array[String])= {
    val (anag, pdr, sito ): (Array[String], Array[String], Array[String]) =
      (payload(0)(CONST.seven), payload(1)(CONST.seven)) match {
        case (CONST.ANAG, CONST.CC_PDR) => (payload.apply(0), payload.apply(1), Array.empty[String])
        case (CONST.CC_PDR, CONST.ANAG) => (payload.apply(1), payload.apply(0), Array.empty[String])
      }
    (anag, pdr, sito )
  }

  private def getAnagPdrSito(payload: Seq[Array[String]] ): (Array[String], Array[String], Array[String])= {
    val (anag, pdr, sito ): (Array[String], Array[String], Array[String]) =
      (payload(0)(CONST.seven), payload(1)(CONST.seven), payload(2)(CONST.seven)) match {
        case (CONST.ANAG, CONST.CC_PDR, CONST.CC_SITO) => (payload(0), payload(1), payload(2))
        case (CONST.ANAG, CONST.CC_SITO, CONST.CC_PDR) => (payload(0), payload(2), payload(1))
        case (CONST.CC_SITO, CONST.ANAG, CONST.CC_PDR) => (payload(1), payload(2), payload(0))
        case (CONST.CC_SITO, CONST.CC_PDR, CONST.ANAG) => (payload(2), payload(1), payload(0))
        case (CONST.CC_PDR, CONST.ANAG, CONST.CC_SITO) => (payload(1), payload(0), payload(2))
        case (CONST.CC_PDR, CONST.CC_SITO, CONST.ANAG) => (payload(2), payload(0), payload(1))
      }
    (anag, pdr, sito )
  }

  def getRecordTypeArrays(fve: FVE): (Array[String], Array[String], Array[String])  = {
    val payload: Seq[Array[String]] = fve.payload.get
    var (anag, pdr, sito ): (Array[String], Array[String], Array[String]) = (Array.empty[String], Array.empty[String],
      Array.empty[String])
    if (payload.size == 2) {
      getAnagPdr(payload)
    } else if (payload.size == 3) {
      getAnagPdrSito(payload)
    } else {
      (anag, pdr, sito )
    }
  }
}
