package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import java.util.UUID

import it.enel.next.platform.cross.coremodule.formalvalidation.application.FormalValidationRouting
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGValidMappingObject, Outcome, EEGSupplyActivationFVEntity => FVE}
import it.enel.next.platform.cross.model.ValidationError
import it.enel.next.platform.framework.collection.common.datastructure.{NextCollection, NextFrame}
import it.enel.next.platform.framework.common.metadata.{NextMetadata, NextObjectWrapper}
import it.enel.next.platform.framework.common.model.application._
import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.enum.{EEGLREventTypeEnum, EEGLRRoutingOutputEnum}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.EEGPostSalesBuilder
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.EEGSupplyActivationDataContext
import it.enel.next.enelenergia.gas.common.model.discard.EEGFormalValidationDiscard
import it.enel.next.enelenergia.gas.common.model.postasales.EEGPostSales
import it.enel.next.platform.framework.application.model.CustomOutput
import it.enel.next.platform.framework.common.logging.Logging
import it.enel.next.platform.framework.common.model.NextKey
import it.enel.next.platform.framework.common.model.discard.StatusNote
trait EEGSupplyActivationFVRS extends FormalValidationRouting[TLR, FVE, EEGSupplyActivationDataContext,
  EEGValidMappingObject] with Logging {
//scalastyle:off
  override def route(custom: Map[CustomDestination, NextCollection[(NextKey, NextObjectWrapper[FVE],
    Option[EEGSupplyActivationDataContext])]], withoutError: NextCollection[NextObjectWrapper[EEGValidMappingObject]],
                     withError: NextCollection[(NextObjectWrapper[FVE], Seq[ValidationError])],
                     withSemanticError: NextCollection[(NextObjectWrapper[EEGValidMappingObject],
                       Seq[ValidationError])])
                    (implicit ctx: NextExecutionContext): CustomOutput[TLR] = {
    val outcomeDestination = FileDestination(WriteActionEnum.WRITE_INSERT, "EEGSupplyActivationFVEntityFile" )
    val validDestination = EventDestination(EEGLREventTypeEnum.EEG_LOADER_REGISTRY, WriteActionEnum.WRITE_INSERT)
    val discardedDestination = EntityDestination(EEGLRRoutingOutputEnum.DISCARDED_ITEM,
      WriteActionEnum.WRITE_INSERT, EEGFormalValidationDiscard.identifierName)
    //SUPPLY_ACTIVATION_FORMAL_VALIDATION_POSTSALES
    val postsalesDestination = EntityDestination(EEGLRRoutingOutputEnum.POST_SALES,
      WriteActionEnum.WRITE_INSERT, "EEGPostSales")

    val outcomeRecords = withError.filter(_._1.optEntity.get.isValid).filter(_._1.optEntity.get.payload.get.size > 1).
      map(e => NextObjectWrapper( Outcome.parse(e._1, e._2), NextMetadata.empty))

    val discardedSyn: NextCollection[EEGFormalValidationDiscard] = withError.map(elem => {
      val e: FVE = elem._1.optEntity.get
      val validationErrors: Seq[ValidationError] = elem._2
      val discardedInpuString = e.payload match {
        case Some(payload) => payload.map(_.mkString(",")).mkString("\n")
        case None if e.unknownPayload.isDefined => e.unknownPayload.get.mkString(",")
        case _ => "INPUT STRING EMPTY"
      }

      EEGFormalValidationDiscard(
        e.meta.elaborationId,
        discardedInpuString,
        e.processingNote,
        e.dtAcquisition,
        e.dtProcessing,
        e.source,
        UUID.randomUUID(),
        e.timeZone,
        validationErrors.map(v => StatusNote(v.error.name, "0", Option(v.errorDetails)))
      ) //errorDetails
    })

    val postSalesDiscardedRecords: NextCollection[EEGPostSales] =
      withError.filter(e => e._1.optEntity.isDefined).filter(e => e._1.optEntity.get.payload.isDefined).
        filter(e => e._1.optEntity.get.payload.get.size > 1).
        map(elem => EEGPostSalesBuilder.create(elem._1.optEntity.get, elem._2)).filter(e => e.isDefined).map(_.get)

    var tofile: Option[Map[FileDestination, NextFrame]] = Option.empty[Map[FileDestination, NextFrame]]
    if (outcomeRecords.count > 0) {
      tofile = Some(Map(outcomeDestination -> outcomeRecords.toNextFrame()))
    } else {
      tofile = None
    }

    val entities = Some(Map(discardedDestination -> discardedSyn.toNextFrame(),
      postsalesDestination -> postSalesDiscardedRecords.toNextFrame()))
    val events = Some(Map(validDestination -> withoutError.toNextFrame()))

    //Custom output definitions
    CustomOutput(CleanupFunction.empty, entities, events, None, tofile)
  }
//scalastyle:on
}
