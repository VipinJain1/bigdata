package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.EEGValidMappingObject
import it.enel.next.platform.cross.coremodule.formalvalidation.application.FormalValidationSemanticValidation
import it.enel.next.platform.cross.model.ValidationError
import it.enel.next.platform.framework.common.metadata.NextObjectWrapper
import it.enel.next.platform.framework.common.model.application.NextExecutionContext

trait EEGSupplyActivationFVSS extends FormalValidationSemanticValidation[TLR,EEGValidMappingObject] {
  override def validateSemantically(entity: NextObjectWrapper[EEGValidMappingObject])
                                   (implicit ctx: NextExecutionContext):
  (Boolean, Seq[ValidationError]) = (false, Seq.empty)
}
