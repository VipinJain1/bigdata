package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationFVE, EEGSupplyActivationFVEEnum, EEGSupplyActivationConstants => CONST}
import org.scalatest.{FlatSpec, Matchers}

class EEGLRSyntacticValidationPdrTest extends FlatSpec with Matchers {
//scalastyle:off

  "pdr blocking R01" should "run" in {
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(0)
  }

  /*"pdr blocking R01_ERROR1" should "run" in {
    //changed anag(16) to "X"
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;X;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    val err = test.errorList
    test.errorList.size shouldBe(1)
  //  test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, anag.length - CONST.seven))
  }*/

  "pdr blocking R01_ERROR" should "run" in {
    //Increased length of PRD record by adding extra element at pdr(53)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu;EXTRA"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    val err = test.errorList
    test.errorList.size shouldBe(1)
    //  test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, anag.length - CONST.seven))
  }

  "pdr blocking R02" should "run" in {
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(0)
  }

  "pdr blocking R02_ERROR" should "run" in {
    //Decreased length of PRD record by removing pdr(52)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  // FIXME however this testcase will not work as in the beginning of the function only we are checking whether the pdr(7) == CC_PDR
//  "pdr blocking R03_ERROR" should "run" in {
//    //PDR(7) is kept empty
//    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
//    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
//    val crmId: String = "pv0:0a128memeu"
//
//    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
//    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
//    val test = new EEGSupplyActivationFVSYSImpl()
//
//    val anag = crmId +: anagStr.split(";")
//    val pdr = crmId +: pdrStr.split(";")
//
//    test.ccpdrBlockingChecks(anag,pdr)
//    test.errorList.size shouldBe(1)
//  }

  "pdr blocking R04_ERROR1" should "run" in {
    //PDR(8) is kept empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    // test.errorList.size shouldBe(1)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Pod Code"))
  }

  "pdr blocking R04_ERROR2" should "run" in {
    // pdr(8) != anag(17)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759488;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    //test.errorList.size shouldBe(1)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_40, true))
  }

  "pdr blocking R04_ERROR3" should "run" in {
    //length of pdr(8) < 14 but make sure pdr(8) is equal to anag(17)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;0088120575949;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;0088120575949;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R04_ERROR4" should "run" in {
    //length of pdr(8) > 14 but make sure pdr(8) is equal to anag(17)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;008812057594999;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;008812057594999;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R05_ERROR1" should "run" in {
    //pdr(10) is made empty , anag(16)=B and pdr(51)!= VCA
    val anagStr: String =
      """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag, pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_3, true))
  }

  "pdr blocking R05_ERROR2" should "run" in {
    //pdr(10) and pdr(11) is made empty and anag(16)=M
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;;;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_4, true))
  }



  "pdr blocking R05_ERROR3" should "run" in {
    //pdr(10) is made float
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650.123;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, pdr(CONST.ten)))
  }


  "pdr blocking R05_ERROR4" should "run" in {
    //length pdr(10) > 8
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650123456;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Annual contract volume pdr", pdr(CONST.ten).length, CONST.fourteen))
  }


  "pdr blocking R06_ERROR1" should "run" in {
    //pdr(11) is made float
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12.1234;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, pdr(CONST.ten)))
  }

  "pdr blocking R06_ERROR2" should "run" in {
    //length pdr(11) > 8
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;123456789;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Distributor annual consumption", pdr(CONST.eleven).length, CONST.eight))
  }

  //FIXME check fails
  "pdr blocking R07_ERROR1" should "run" in {
    //pdr(12) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R07_ERROR2" should "run" in {
    //length pdr(12) > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;1201234567891;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R08_ERROR1" should "run" in {
    //pdr(13) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "cc early date"))
  }

  "pdr blocking R08_ERROR2" should "run" in {
    //pdr(13) is not valid date
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;82/29/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, true, "cc early date"))
  }


  "pdr blocking R08_ERROR3" should "run" in {
    //pdr(13)!= anag(8)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;21/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7_3, true, "Start date cc", anag(CONST.eight), pdr(CONST.thirteen)))
  }

  "pdr blocking R09_ERROR1" should "run" in {
    //length pdr(15) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;15;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList  should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "use type", pdr(CONST.fifteen), CONST.one))
  }

  "pdr blocking R10_ERROR" should "run" in {
    //length pdr(16)> 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;16;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList  should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "Industrial uses", pdr(CONST.sixteen), CONST.one))
  }

  //FIXME check fails
  "pdr blocking R11_ERROR1" should "run" in {
    //pdr(17) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R11_ERROR2" should "run" in {
    //length pdr(17) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;1712345;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "Value Percentage industrial uses", pdr(CONST.seventeen).length, CONST.six))
  }


  "pdr blocking R12_ERROR" should "run" in {
    //length pdr(18) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;18;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  //FIXME check fails as integer also passes as float
  "pdr blocking R13_ERROR1" should "run" in {
    //pdr(19) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R13_ERROR2" should "run" in {
    //length pdr(19) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;1912345;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }



  "pdr blocking R14_ERROR" should "run" in {
    //length pdr(20) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;20;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  //FIXME check fails as integer also passes as float
  "pdr blocking R15_ERROR1" should "run" in {
    //pdr(21) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R15_ERROR2" should "run" in {
    //length pdr(21) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;2112345;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R16_ERROR" should "run" in {
    //length pdr(22) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;22;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  //FIXME check fails as integer also passes as float
  "pdr blocking R17_ERROR1" should "run" in {
    //pdr(23) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R17_ERROR2" should "run" in {
    //length pdr(23) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;2312345;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R18_ERROR" should "run" in {
    //length pdr(24) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;24;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R19-ERROR1" should "run" in {
    //pdr(25) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R19_ERROR2" should "run" in {
    //length pdr(25) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;2512345;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R20_ERROR" should "run" in {
    //length pdr(26) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;26;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R21_ERR0R1" should "run" in {
    //pdr(27) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R21_ERROR2" should "run" in {
    //length pdr(27) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;2712345;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R22_ERROR" should "run" in {
    //length pdr(28) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;28;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R23_ERROR1" should "run" in {
    //pdr(29) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R23_ERROR2" should "run" in {
    //length pdr(29) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;2912345;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R24_ERROR" should "run" in {
    //length pdr(30) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;30;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R25_ERROR1" should "run" in {
    //pdr(31) is made integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R25_ERROR2" should "run" in {
    //length pdr(31) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;3112345;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R26_ERROR" should "run" in {
    //length pdr(32) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;32;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R27_ERROR1" should "run" in {
    //pdr(33) is madde integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R27_ERROR2" should "run" in {
    //length pdr(33) > 6
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;3312345;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R29_ERROR" should "run" in {
    //length pdr(42) > 3
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R30_ERROR" should "run" in {
    //length pdr(43) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;10;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R31_ERROR" should "run" in {
    //length pdr(44) > 5
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;123456;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R32_ERROR1" should "run" in {
    //pdr(45) is empty and anag(16) != M
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R32_ERROR2" should "run" in {
    //length pdr(45) > 11
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;123456789999;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R33_ERROR1" should "run" in {
    //pdr(46) isEmpty && anag(51) != 'VCA'
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }


  "pdr blocking R33_ERROR2" should "run" in {
    //pdr(46)!= G and anag(33) == S
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;S;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  "pdr blocking R33_ERROR3" should "run" in {
    //length pdr(46) > 1
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;SSS;E;2386;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }

  //FIXME check will fail as code for this check is commented
  "pdr blocking R34_ERROR" should "run" in {
    //pdr(50) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;;ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;00881205759490;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdrStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;17.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    //val fve = EEGSupplyActivationFVEObject.parse(crmId, Seq((crmId, anag.split(";")), (crmId, pdr.split(";"))))
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val pdr = crmId +: pdrStr.split(";")

    test.ccpdrBlockingChecks(anag,pdr)
    test.errorList.size shouldBe(1)
  }
  //scalastyle:on
}
