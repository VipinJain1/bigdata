package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationFVE,
  EEGSupplyActivationFVEEnum, EEGSupplyActivationConstants => CONST}
import org.scalatest.{FlatSpec, Matchers}

class EEGLRSyntacticValidationSitoTest extends FlatSpec with Matchers {

  "sito valid record" should "run" in {
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList.size shouldBe(0)
  }

  "sito blocking M01_ERROR" should "run" in {
    //sito.length != 29(added 30th element in sito record)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu;extra_element"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1008, true, sito.size - CONST.seven))
  }

  "sito blocking M02_ERROR1" should "run" in {
    //sito(7) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "tipo record"))
  }

  "sito blocking M02_ERROR2" should "run" in {
    //sito(7)==CC_SITO && anag(16)==M
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;M;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_36, true))
  }


  "sito blocking M03_ERROR1" should "run" in {
    //sito(8) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "numero utente"))
  }

  "sito blocking M03_ERROR2" should "run" in {
    //sito(8) is not integer
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818.336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NUMINT, true, "numero utente",
      sito(CONST.eight)))
  }

  //FIXME Here the length of sito(8) is greater than 20 which makes it of long type and hence will fail beacause of previos check which checks for Int type
  "sito blocking M03_ERROR4" should "run" in {
    //sito(8).length > 20
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951123456789123;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "numero utente",
      sito(CONST.eight).length, CONST.twenty))
  }

  "sito blocking M01_ERROR3" should "run" in {
    // sito(8) != anag(12)
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336952;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_40, true))
  }

  "sito blocking M04_ERROR1" should "run" in {
    //sito(9) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1012, true, "data inizio cc"))
  }

  "sito blocking M04_ERROR2" should "run" in {
    //sito(9) is an invalid date
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/44/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_0x1_2, true, "data inizio cc"))
  }

  //FIXME this check will fail because of previous check which checks for invalid date format
  "sito blocking M04_ERROR3" should "run" in {
    //sito(9).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/20188;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "data inizio cc"
      , sito(CONST.nine).length, CONST.twenty))
  }

  "sito blocking M04_ERROR4" should "run" in {
    // sito(9) > anag(8) in terms of date
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/09/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_7_3, true, anag(CONST.eight), sito(CONST.nine)))
  }


//FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M05_ERROR1" should "run" in {
    //sito(12) is String
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;twelve;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "coefficiente profilatura"))
  }

//
  "sito blocking M05_ERROR2" should "run" in {
    //sito(12).length > 13
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1131123456.789;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "coefficient profiling", sito(CONST.twelve).length, CONST.thirteen))
  }


  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M06_ERROR1" should "run" in {
    //sito(13) is String
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;thirteen;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 01"))
  }

  "sito blocking M06_ERROR2" should "run" in {
    //sito(13).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;1131123456.789;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 01"
      , sito(CONST.thirteen).length, CONST.ten))
  }


  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M07_ERROR1" should "run" in {
    //sito(14) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;fourteen;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 02"))
  }


  "sito blocking M07_ERROR2" should "run" in {
      //sito(14).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;1131123456.789;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 02"
      , sito(CONST.fourteen).length, CONST.ten))
  }


  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M08_ERROR" should "run" in {
    //sito(15) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;fifteen;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 03"))
  }

  "sito blocking M08_ERROR2" should "run" in {
    //sito(15).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;1131123456.789;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 03"
      , sito(CONST.fifteen).length, CONST.ten))
  }


  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M09_ERROR1" should "run" in {
    //sito(16) is String
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;Sixteen;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 04"))
  }

  "sito blocking M09_ERROR2" should "run" in {
    //sito(16).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;1131123456.789;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 04"
      , sito(CONST.sixteen).length, CONST.ten))
  }


  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M10_ERROR1" should "run" in {
    //sito(17) is String
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;seventeen;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 05"))
  }

  "sito blocking M10_ERROR2" should "run" in {
    //sito(17).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;1131123456.789;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 05"
      , sito(CONST.seventeen).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking M11_ERROR1" should "run" in {
    //sito(18) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;eighteen;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 06"))
  }

  "sito blocking M11_ERROR2" should "run" in {
    // sito(18).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862123123;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 06"
      , sito(CONST.eighteen).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M12_ERROR1" should "run" in {
    //sito(19) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;nineteen;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 07"))
  }

  "sito blocking M12_ERROR2" should "run" in {
    // sito(19).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;44376423324234;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain( EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 07"
      , sito(CONST.nineteen).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M13_ERROR1" should "run" in {
    //sito(20) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;twenty;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 08"))
  }

  "sito blocking M13_ERROR2" should "run" in {
    // sito(20).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;44376423324234;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain( EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 08"
      , sito(CONST.twenty).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M14_ERROR1" should "run" in {
    // sito(21) is String
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;191443;twentyOne;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 09"))
  }

  "sito blocking M14_ERROR2" should "run" in {
    // sito(21).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;191443;436058;44376423324234;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 09"
      , sito(CONST.twentyOne).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M15_ERROR1" should "run" in {
    //sito(22) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;191443;339940;twentyTwo;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 10"))
  }

  "sito blocking M15_ERROR2" should "run" in {
    // sito(22).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;191443;436058;339940;44376423324234;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 10"
      , sito(CONST.twentyTwo).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M16_ERROR1" should "run" in {
    // sito(23) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;191443;339940;403439;twentyThree;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 11"))
  }

  "sito blocking M16_ERROR2" should "run" in {
    // sito(23).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;191443;436058;339940;403439;44376423324234;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 11"
      , sito(CONST.twentyThree).length, CONST.ten))
  }

  //FIXME This check will fail for integer value as integer value is accepted as float
  "sito blocking  M17_ERROR1" should "run" in {
    // sito(24) is string
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;436058;191443;339940;403439;435530;twentyFour;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1011, true, "volume cc mese 12"))
  }

  "sito blocking M17_ERROR2" should "run" in {
    // sito(23).length > 10
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;191443;436058;339940;403439;435530;44376423324.234;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "volume cc mese 12"
      , sito(CONST.twentyFour).length, CONST.ten))
  }

  "sito blocking M18_ERROR1" should "run" in {
    // sito(26) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true, "causale processo"))
  }

  "sito blocking M18_ERROR2" should "run" in {
    // sito(26) != ATTIVAZIONE
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;NOT_ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_31, true, sito(CONST.twentySix)))
  }

  //FIXME this check will fail because of previous check as sito(26) != ATTIVAZIONE
  "sito blocking M18_ERROR3" should "run" in {
    //error inserted at sito(26).length > 30
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;NOTATTIVAZIONENOTATTIVAZIONENOTATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "causale processo", sito(CONST.twentySix).length, CONST.thirty))
  }


  "sito blocking M19_ERROR1" should "run" in {
    //  sito(27) is empty
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()
    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")
    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_NoValObbl_0, true,"sottocausale process"))
  }

  "sito blocking M19_ERROR2" should "run" in {
    //sito(27) in('VARIAZIONEUSO', 'RICONTRATTUALIZZAZIONE', 'MIGRAZIONE', 'MOGE')
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VARIAZIONEUSO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_35, true))
  }

  "sito blocking M19_ERROR3" should "run" in {
    //sito(27).length > 30
    val anagStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;ANAG;01/08/2018;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;11881205759499;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;01/08/2018;;50001;G0004;;;;;;A;;01/08/2018;E;1642;CD;;C;;;9;;;;;;;;;01/08/2018;E;123;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sitoStr: String = """A_ANGCRM_INT;50;1540800611000;223456;anagrafica_gas_mm.csv;;CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;422711;397176;417188;411616;431935;418862;443764;436058;191443;339940;403439;435530;N;ATTIVAZIONE;VOLTURA SENZA ACCOLLO SENZA ACCOLLO;pv0:0a128memeu"""
    val crmId: String = "pv0:0a128memeu"

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS {}
    val test = new EEGSupplyActivationFVSYSImpl()

    val anag = crmId +: anagStr.split(";")
    val sito = crmId +: sitoStr.split(";")

    test.ccsitoBlockingChecks(anag,sito)
    test.errorList should contain(EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1001, true, "sottocausale process ", sito(CONST.twentySeven).length, CONST.thirty))
  }

}
