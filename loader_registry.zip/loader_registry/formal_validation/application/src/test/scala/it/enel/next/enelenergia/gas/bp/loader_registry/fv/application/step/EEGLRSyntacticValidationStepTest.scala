package it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.step

import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.{EEGSupplyActivationFVEObject, EEGSupplyActivationFVEntity}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.application.service.{RecordTypeSegregatorService}
import it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model.{EEGSupplyActivationFVE, EEGSupplyActivationFVEEnum}
import it.enel.next.platform.cross.model.ValidationError
import org.scalatest.{FlatSpec, Matchers}

import scala.collection.mutable.ListBuffer

class EEGLRSyntacticValidationStepTest extends FlatSpec with Matchers{

  "Check RecordTypeSegregatorService" should " get all different record types" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;5;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr  = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito  = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq( (crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val (anagr, pdrr, sitor) = RecordTypeSegregatorService.getRecordTypeArrays(fve)
    anagr(7).shouldEqual("ANAG")
    pdrr(7).shouldEqual("CC_PDR")
    sitor(7).shouldEqual("CC_SITO")
  }

  "Check genericChecks " should "errors list empty" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecks(fve)
    test.errorList.size shouldEqual 0
  }

  "Check genericChecks with wrong records" should "nonempty" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    //Changed M to B in below ANAG
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecks(fve)
    test.errorList.size shouldEqual 1
  }

  "Check genericChecks G05" should "contain correct error" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecks(fve)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true))
  }

  "Check genericChecks G05" should "contain another error or empty" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;B;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""

    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")


    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecks(fve)
    test.errorList shouldNot contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_CRMRICHKO, true))
  }

  "Check genericChecksSpecific G06-07" should "empty" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;15351790003420;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;;;5;G0004;;;;;;A;;01/08/2018;E;1642;;;;;;;;;;;;;;;;;;ATTIVAZIONE;PRIMA ATTIVAZIONE"""
    val pdr  = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;15351790003420;500;500;1;009114;01/08/2018;31/12/2099;P;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;S;100,00;;;;;;;;;004;1;007E1;1116;M;;;;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;2455;2475;1131;539;0;0;0;0;0;552;1371;2498;N;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmid = "ppv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")


    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecksSpecific(anagArr, pdrArr, sitoArr)
    test.errorList.size should be (0)
  }

  "Check genericChecksSpecific G06-07" should "return ERR_1042_22 error" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;;05736981001;ENEL SI S.R.L.;;818336951;00000044633006;ENEL SI S.R.L.;05736981001;B;15351790003420;;1;1;D;VIA VIGORELLI;;CASTEGGIO;27045;PV;;SNC;;;;Accessibile;N;DUG;;001007;;018037;I;34463300;;;;;Metano;AEM2034116002885;NC;M;;;5;G0004;;;;;;A;;01/08/2018;E;1642;;;;;;;;;;;;;;;;;;ATTIVAZIONE;PRIMA ATTIVAZIONE"""
    val pdr  = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;15351790003420;500;500;1;009114;01/08/2018;31/12/2099;P;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;N;0,00;S;100,00;;;;;;;;;004;1;007E1;1116;M;;;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;818336951;01/08/2018;31/12/2099;S;1,3;2455;2475;1131;539;0;0;0;0;0;552;1371;2498;N;ATTIVAZIONE;PRIMA ATTIVAZIONE;pv0:0a128memeu"""
    val crmid = "ppv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")


    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val result = test.genericChecksSpecific(anagArr, pdrArr, sitoArr)
    test.errorList should contain (EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_1042_22, true))
  }

  "Check checkA49Partial " should "order" in {

    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val result = test.checkA49Partial(anagArr)
    result should be (true)
  }

  "Check anagBlockingChecks " should "empty" in {
    class EEGSupplyActivationFVSYSImpl extends EEGSupplyActivationFVSYS
    val test = new EEGSupplyActivationFVSYSImpl
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val pdr = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_PDR;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val sito = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||CC_SITO;00881205759499;650;650;12;12.5;20/09/2018;;;;18.5;;19.5;;21.5;;23.5;;25.5;;27.5;;29.5;;31.5;;33.5;0;;3-E0040606;;N;N;;;C3;1;;0;S;E;2386;;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val pdrArr: Array[String] = crmid +: pdr.replace("||", ";").split(";")
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
    val sitoArr: Array[String] = crmid +: sito.replace("||", ";").split(";")

    val fve: EEGSupplyActivationFVEntity = EEGSupplyActivationFVEObject.parse((crmid, Seq((crmid, sitoArr), (crmid, anagArr), (crmid, pdrArr))))
    val result = test.anagBlockingChecks(anagArr)
    test.errorList.size should be (0)
  }

  "Check the error message" should "be correct" in {
    var errL: ListBuffer[ValidationError] = new ListBuffer[ValidationError]
    val anag = """A_ANGCRM_INT;50;1540800611000;123456;anagrafica_gas_mm.csv;||ANAG;20/09/2018;LSSMTT91R11L219S;MATTIA LUSSU;1N00001I3KFMAAA;300441024;;MATTIA LUSSU;;M;00881205759499;;;;D;Via PINEROLO;;PIOSSASCO;10045;TO;;144;;;roccodecanio@libero.it;Non definita;N;;;000807;;001194;;;;;;997;;0049008674;NC;M;20/09/2018;;51000;G0004;;20000;;Non Accessibile;;A;;20/09/2018;E;2386;A;NC;C;20/09/2018;;10;G0004;;;;Non Accessibile;;;;20/09/2018;E;12.2;ATTIVAZIONE;VOLTURA SENZA ACCOLLO;pv0:0a128memeu"""
    val crmid = "pv0:0a128memeu"
    val anagArr: Array[String] = crmid +: anag.replace("||", ";").split(";")
//    val r = EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23, true, "saarefae12".length, 4)
    errL += EEGSupplyActivationFVE(EEGSupplyActivationFVEEnum.ERR_GASVAL23, true, anagArr(51).length, 4)
    val s = errL.toSeq
    println(s)
  }


}
