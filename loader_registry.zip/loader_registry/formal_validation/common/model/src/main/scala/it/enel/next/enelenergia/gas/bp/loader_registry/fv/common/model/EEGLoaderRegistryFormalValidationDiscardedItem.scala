package it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model

import java.time.{ZoneId, ZonedDateTime}
import java.util.UUID

import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.platform.framework.common.model.NextObject

case class EEGLoaderRegistryFormalValidationDiscardedItem (override val uid: UUID,
                                                           override val processingNote: Option[String],
                                                           override val dtAcquisition: ZonedDateTime,
                                                           override val dtProcessing: Option[ZonedDateTime],
                                                           override val source: String,
                                                           override val timeZone: ZoneId,
                                                           jobID: String,
                                                           elaborationId: String,
                                                           filename: String,
                                                           payload: String,
                                                           errorDetails:String) extends NextObject with TLR {

  override def key: String = elaborationId
}

object EEGLoaderRegistryFormalValidationDiscardedItem {

  def identifierName: String = "EEGLoaderRegistryFormalValidationDiscardedItem"
}
