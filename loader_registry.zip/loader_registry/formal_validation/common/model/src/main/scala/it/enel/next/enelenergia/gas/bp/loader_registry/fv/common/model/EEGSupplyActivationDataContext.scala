package it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model

import it.enel.next.enelenergia.common.model.{EnelEnergiaTailor => TLR}
import it.enel.next.platform.framework.common.model.application.NextDataContext
import it.enel.next.enelenergia.gas.bp.loader_registry.common.model.EEGSupplyActivationFVEntity

trait EEGSupplyActivationDataContext
  extends NextDataContext[TLR,EEGSupplyActivationFVEntity,EEGSupplyActivationDataContext]
