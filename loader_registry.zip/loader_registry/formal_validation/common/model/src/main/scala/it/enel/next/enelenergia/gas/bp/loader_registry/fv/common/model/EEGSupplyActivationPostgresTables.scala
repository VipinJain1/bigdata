package it.enel.next.enelenergia.gas.bp.loader_registry.fv.common.model

object EEGSupplyActivationPostgresTables {

  val T_SAT = "REG_STATO_ATTTRA"
  val T_AA = "REG_TERRITORIAL_AREA"
  val T_AP = "REG_COUNTY"
  val T_TC = "GST_O_SAPDPC_TIPO_CONTRATTO"
  val T_AD = "REG_DISTRIBUTOR"
  val T_AR = "GST_DISTR_COUNTY_AREA"
  val T_GPC = "GST_CRM_PROCESSO_OPERAZIONE"
  val T_RC = "GST_CRM_RATE_CATEGORY"
  val T_RP = "REG_REGOLA_PREVISIONI"
  val T_CONF = "GST_PROC_PARAM_CONF"
  val T_SD = "REG_DISTRIBUTOR"
  val T_CI = "REG_COMUNI"
  val T_PDR = "REG_POD_STATUS"
  val T_CR = "REG_REMI"
  val T_MB = "REG_METER_BRAND"
  val T_CAL = "REG_GAUGE"
  val T_AF = "REG_PHYSICAL_ACCESSIBILITY"
  val T_MT = "REG_MEASURE_TYPE"
  val T_UC = "REG_USE_CATEGORY"
  val T_CP = "REG_CLASSE_PRELIEVO"
  val T_PP = "CONSUMPTION_PROFILES"
  val T_RF = "REG_READING_FREQUENCY"
  val T_ZONE = "REG_ZONA_CLIMATICA"
  val T_RPC = "REG_PROCESS_CAUSAL"
}

