package it.enel.next.enelenergia.gas.bp.loader_registry.common.enum

import it.enel.next.platform.framework.common.model.process.{ProcessEnum, ProcessEnumBase}

trait EEGLRProcessEnum extends ProcessEnum {

  val EEGLoaderRegistryFormalValidationNP = ProcessEnumBase.ProcessEnumVal("EEGLoaderRegistryFormalValidationNP")
  val EEGLoaderRegistrySubstantialValidationNP =
    ProcessEnumBase.ProcessEnumVal("EEGLoaderRegistrySubstantialValidationNP")

}

object EEGLRProcessEnum extends EEGLRProcessEnum

