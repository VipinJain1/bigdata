package it.enel.next.enelenergia.gas.bp.loader_registry.common.model

import java.time.{ZoneId, ZonedDateTime}
import java.util.UUID

import it.enel.next.enelenergia.common.model.EnelEnergiaTailor
import it.enel.next.enelenergia.gas.common.model.contract_site.EEGContractSite
import it.enel.next.enelenergia.gas.common.model.measure.EEGCommercialMeasure
import it.enel.next.enelenergia.gas.common.model.registry.EEGRegistry
import it.enel.next.platform.cross.model.TypologicalPercentages
import it.enel.next.platform.framework.common.model.NextObject

case class EEGValidMappingObject(gasContractSite: Option[EEGContractSite],
                                 typologicalPercentages: Option[TypologicalPercentages],
                                 registry: Option[EEGRegistry], measure: Option[EEGCommercialMeasure])
  extends  NextObject with EnelEnergiaTailor{
  override def key: String = "Key"

  override def processingNote: Option[String] = None

  override def dtAcquisition: ZonedDateTime = ZonedDateTime.now()

  override def dtProcessing: Option[ZonedDateTime] = None

  override def source: String = "source"

  override def uid: UUID = UUID.randomUUID()

  override def timeZone: ZoneId = ZoneId.systemDefault()
}

