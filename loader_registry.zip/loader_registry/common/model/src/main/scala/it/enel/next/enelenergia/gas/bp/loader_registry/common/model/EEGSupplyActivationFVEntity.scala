package it.enel.next.enelenergia.gas.bp.loader_registry.common.model

import java.time.{Instant, LocalDateTime, ZoneId, ZonedDateTime}
import java.util.UUID
import it.enel.next.enelenergia.common.model.EnelEnergiaTailor
import it.enel.next.platform.cross.model.FormalValidationEntity

object PayloadType {
  type PT = Option[Seq[Array[String]]]
}

case class EEGSupplyActivationFVEntity(override val payload: PayloadType.PT,
                                       val unknownPayload: Option[Array[String]],
                                       val meta: EEGSupplyActivationFVEntityMeta,
                                       val isValid: Boolean,
                                       override val file: String,
                                       override val key: String,
                                       override val processingNote: Option[String],
                                       override val dtAcquisition: ZonedDateTime,
                                       override val dtProcessing: Option[ZonedDateTime],
                                       override val source: String,
                                       override val uid: UUID,
                                       override val timeZone: ZoneId)extends FormalValidationEntity with
  EnelEnergiaTailor{
  override type PayloadType = PayloadType.PT


  require( (!payload.isEmpty && unknownPayload.isEmpty) || (payload.isEmpty && !unknownPayload.isEmpty))

}
case class EEGSupplyActivationFVEntityMeta(pid:String, //0
                                           userId:String, //1
                                           ingestionTS:String, //2
                                           elaborationId:String, //3
                                           fileName:String, //4
                                           archiveName:Option[String]) //5

object EEGSupplyActivationFVEObject {

  def parse(rddRecord: (String, Seq[(String, Array[String])])): EEGSupplyActivationFVEntity = {

    val payloadMeta: (String, Array[String]) = rddRecord._2.head
    val pid: String = payloadMeta._2(Constants.PID_METADATA_FIELD + 1)
    val userId: String = payloadMeta._2(Constants.USER_ID_METADATA_FIELD + 1)
    val elaborationId: String = payloadMeta._2(Constants.ELABORATION_ID_METADATA_FIELD + 1)
    val archiveName: Option[String] = Some(payloadMeta._2(Constants.ARCHIVE_NAME_METADATA_FIELD + 1))
    val tsAcquisition: String = payloadMeta._2(Constants.ACQUISITION_TIMESTAMP_METADATA_FIELD + 1)
    val fileName: String = payloadMeta._2(Constants.FILE_NAME_METADATA_FIELD + 1)
    val meta = EEGSupplyActivationFVEntityMeta(pid, userId, tsAcquisition, elaborationId, fileName, archiveName)

    val key: String = rddRecord._1
    val zoneId: ZoneId = ZoneId.of("UTC")
    val dateTime: LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(tsAcquisition.toLong), zoneId)
    val dtAcquisition: ZonedDateTime = ZonedDateTime.of(dateTime, zoneId)
    val now: LocalDateTime = LocalDateTime.ofInstant(Instant.now(), zoneId)
    val dtProcessing = ZonedDateTime.of(now, zoneId)
    val source: String = Constants.EMPTY

    EEGSupplyActivationFVEntity(Some(rddRecord._2.map(_._2)),
      None,
      meta,
      true,
      fileName,
      key,
      None,
      dtAcquisition,
      Some(dtProcessing),
      source, UUID.randomUUID(), zoneId)
  }

  def parseUnknown(rddRecord: (String , Array[String])) : EEGSupplyActivationFVEntity = {
    val payloadMeta: (String, Array[String]) = rddRecord
    val pid: String = payloadMeta._2(Constants.PID_METADATA_FIELD)
    val userId: String = payloadMeta._2(Constants.USER_ID_METADATA_FIELD)
    val fileId: String = payloadMeta._2(Constants.ELABORATION_ID_METADATA_FIELD)
    val fileName: String = payloadMeta._2(Constants.FILE_NAME_METADATA_FIELD)
    val archiveName: Option[String] = Some(payloadMeta._2(Constants.ARCHIVE_NAME_METADATA_FIELD))
    val tsAcquisition: String = payloadMeta._2(Constants.ACQUISITION_TIMESTAMP_METADATA_FIELD)
    val elaborationId: String = payloadMeta._2(Constants.ELABORATION_ID_METADATA_FIELD)
    val meta = EEGSupplyActivationFVEntityMeta(pid, userId, tsAcquisition, elaborationId, fileName, archiveName)

    val key: String = Constants.EMPTY
    val zoneId: ZoneId = ZoneId.of("UTC")
    val dateTime: LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(tsAcquisition.toLong),zoneId)
    val dtAcquisition: ZonedDateTime = ZonedDateTime.of(dateTime,zoneId)
    val now: LocalDateTime = LocalDateTime.ofInstant(Instant.now(),zoneId)
    val dtProcessing = ZonedDateTime.of(now,zoneId)
    val source: String = Constants.EMPTY

    EEGSupplyActivationFVEntity(None,
      Some(rddRecord._2),
      meta,
      false,
      fileName,
      key,
      None,
      dtAcquisition,
      Some(dtProcessing),
      source, UUID.randomUUID(), zoneId)
  }

}

protected  object Constants {
  val PID_METADATA_FIELD: Int = 0
  val USER_ID_METADATA_FIELD: Int = 1
  val ACQUISITION_TIMESTAMP_METADATA_FIELD = 2
  val ELABORATION_ID_METADATA_FIELD: Int = 3
  val FILE_NAME_METADATA_FIELD: Int = 4
  val ARCHIVE_NAME_METADATA_FIELD = 5
  val EMPTY = ""
}


