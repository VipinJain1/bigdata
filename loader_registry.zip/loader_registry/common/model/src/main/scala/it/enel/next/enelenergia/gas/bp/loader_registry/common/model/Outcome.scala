package it.enel.next.enelenergia.gas.bp.loader_registry.common.model

import java.time.{ZoneId, ZonedDateTime}
import java.util.UUID

import it.enel.next.enelenergia.common.model.EnelEnergiaTailor
import it.enel.next.platform.cross.model.ValidationError
import it.enel.next.platform.framework.common.logging.Logging
import it.enel.next.platform.framework.common.metadata.NextObjectWrapper
import it.enel.next.platform.framework.common.model.NextObject

case class Outcome ( override val uid: UUID,
                     override val processingNote: Option[String],
                     override val dtAcquisition: ZonedDateTime,
                     override val dtProcessing: Option[ZonedDateTime],
                     override val source: String,
                     override val timeZone: ZoneId,
                     val outcome: String)
  extends NextObject with EnelEnergiaTailor {
    override def key: String = uid.toString
  }

object Outcome extends Logging {
  val indexFiftyThree = 80; val indexFiftyFour = 81; val indexFiftyFive = 82; val indexSeven = 7
  def parse( wrapper: NextObjectWrapper[EEGSupplyActivationFVEntity],  errors: Seq[ValidationError]): Outcome = {

    val entity: EEGSupplyActivationFVEntity = wrapper.optEntity.get

    var anag = entity.payload.get(0)
    if (entity.payload.get.size > 1 && entity.payload.get(1)(indexSeven) == "ANAG") {
      anag = entity.payload.get(1)
    } else if (entity.payload.get.size > 2 && entity.payload.get(2)(indexSeven) == "ANAG") {
      anag = entity.payload.get(2)
    }
    val (result, errDesc) =
      if (errors.size == 0) {
        ("OK", "")
      } else {
        ("KO", errors.head.errorDetails)
      }

    val outcome = Array(anag(indexFiftyThree), anag(indexFiftyFour), anag(indexFiftyFive), result, errDesc)
      .mkString(";")

    Outcome(entity.uid, entity.processingNote, entity.dtAcquisition, entity.dtProcessing, entity.source,
      entity.timeZone, outcome)
  }
}
