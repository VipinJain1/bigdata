package it.enel.next.enelenergia.gas.bp.loader_registry.common.enum

import it.enel.next.platform.service.event.model.{EventTypeEnum, EventTypeEnumBase}

trait EEGLREventTypeEnum extends EventTypeEnum{

  val EEG_LOADER_REGISTRY = EventTypeEnumBase.EventTypeEnumVal("EEGLoaderRegistryEvents")
}

object EEGLREventTypeEnum extends EEGLREventTypeEnum
