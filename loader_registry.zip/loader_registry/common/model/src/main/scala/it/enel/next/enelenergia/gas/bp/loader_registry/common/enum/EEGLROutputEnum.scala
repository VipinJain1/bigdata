package it.enel.next.enelenergia.gas.bp.loader_registry.common.enum

import it.enel.next.platform.framework.common.model.application.{RoutingOutputEnum, RoutingOutputEnumBase}

trait EEGLROutputEnum extends RoutingOutputEnum{

  val OUTPUT_CUSTOM_DISCARDED = RoutingOutputEnumBase.RoutingOutputEnumValue("OUTPUT_CUSTOM_DISCARDED")
  val OUTPUT_CUSTOM_OK = RoutingOutputEnumBase.RoutingOutputEnumValue("OUTPUT_CUSTOM_OK")
  val POSTSALES_KO = RoutingOutputEnumBase.RoutingOutputEnumValue("POSTSALES_KO")
  val POSTSALES_OK = RoutingOutputEnumBase.RoutingOutputEnumValue("POSTSALES_OK")
  val OUTCOME_KO = RoutingOutputEnumBase.RoutingOutputEnumValue("OUTCOME_KO")
  val OUTPUT_DISCARDED = RoutingOutputEnumBase.RoutingOutputEnumValue("OUTPUT_DISCARDED")
  val EEG_LD_FV_OK = RoutingOutputEnum.RoutingOutputEnumValue("EEG_LD_FV_OK")
}

object EEGLROutputEnum extends EEGLROutputEnum
