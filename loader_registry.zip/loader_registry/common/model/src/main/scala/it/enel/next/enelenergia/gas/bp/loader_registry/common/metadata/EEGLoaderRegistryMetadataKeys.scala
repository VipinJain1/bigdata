package it.enel.next.enelenergia.gas.bp.loader_registry.common.metadata

import it.enel.next.platform.framework.common.NestableKeys

trait EEGLoaderRegistryMetadataKeys extends NestableKeys {

  val Source: String = "source"
  val Destination: String = "destination"
  val AdditionalData: String = "extra"
  val JobID = "jobID"
  val ElaborationID = "elaborationID"
  val ProcessCausal = "PROCESS_CAUSAL"
  val ProcessSubcausal = "PROCESS_SUBCAUSAL"
  val ProcessCausalCode = "PROCESS_CAUSAL_CODE"
  val ProcessSubcausalCode = "PROCESS_SUBCAUSAL_CODE"
  val RequestID = "REQUEST_ID"
  val ErrorCodeDes = "errorCode"
  val InputString = "INPUT_STRING"

  def buildExtraKey (source: String, field: String): Unit ={
    buildNested(source, AdditionalData, field)
  }

  val DestinationExtraProcessCausal: String = buildNested(Destination, AdditionalData, ProcessCausal)
  val DestinationExtraProcessSubcausal: String = buildNested(Destination, AdditionalData, ProcessSubcausal)
  val DestinationExtraProcessCausalCode: String = buildNested(Destination, AdditionalData, ProcessCausalCode)
  val DestinationExtraProcessSubcausalCode: String = buildNested(Destination, AdditionalData, ProcessSubcausalCode)
  val DestinationExtraRequestID: String = buildNested(Destination, AdditionalData, RequestID)
  val DestinationExtraJobID: String = buildNested(Destination, AdditionalData, JobID)
  val DestinationExtraErrorCode:String = buildNested(Destination, AdditionalData, ErrorCodeDes)
  val DestinationExtraElaborationID:String = buildNested(Destination, AdditionalData,ElaborationID)
  val DestinationExtraInputString: String = buildNested(Destination, AdditionalData, InputString)

}

object EEGLoaderRegistryMetadataKeys extends EEGLoaderRegistryMetadataKeys

