package it.enel.next.enelenergia.gas.bp.loader_registry.common.enum

import it.enel.next.platform.framework.common.model.application.RoutingOutputEnumBase

trait EEGLRRoutingOutputEnum extends RoutingOutputEnumBase {

  val DISCARDED_ITEM = RoutingOutputEnumBase.RoutingOutputEnumValue("DISCARDED_ITEM")
  val POST_SALES = RoutingOutputEnumBase.RoutingOutputEnumValue("POST_SALES")

}
object EEGLRRoutingOutputEnum extends EEGLRRoutingOutputEnum

